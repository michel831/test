
package com.wm.app.b2b.util;

import com.wm.app.b2b.util.resources.ClientExceptionBundle;
import com.wm.util.EncUtil;
import com.wm.util.ExtBitSet;
import java.util.*;



public class KeyInfo
{

    public KeyInfo()
    {
    }

    public static int getCustID()
    {
        return cust_id;
    }

    public static int getSeqID()
    {
        return seq_id;
    }

    public static int getType()
    {
        return type;
    }

    public static int getLicenses()
    {
    	return 0x7fffffff;
//        return licenses != 0 ? licenses : 0x7fffffff;
    }

    public static int getTNLicenses()
    {
        return tnLicenses;
    }

    public static Date getExpires()
    {
        return expires;
    }

    public static boolean isPartner()
    {
        return true;
    }

    public static boolean isServer()
    {
        return true;
    }

    public static boolean isBeefcake()
    {
        return isType(BEEFCAKE);
    }

    public static boolean isTNServer()
    {
        return isType(TN_SERVER);
    }

    public static boolean isTNPartner()
    {
        return isType(TN_SERVER & PARTNER);
    }

    public static boolean isOEMVersion()
    {
        return isType(OEM);
    }

    public static boolean isType(int t)
    {
        return (type & t) > 0;
    }

    public static boolean isExpired()
    {
        return expires == null || (new Date()).after(expires);
    }

    public static boolean willExpire()
    {
        Calendar c = Calendar.getInstance(TimeZone.getDefault(), Locale.US);
        Calendar _tmp = c;
        c.add(2, 1);
        return expires == null || c.after(expires);
    }

    public static String getString()
    {
        String keyInfo = (new StringBuilder()).append("key: ").append(cust_id).append(", ").append(seq_id).append(", ").append(type).append(", ").append(licenses != 0 ? Integer.toString(licenses) : "unlimited").append(", ").append(expires).toString();
        if(isType(TN_SERVER) && isType(PARTNER))
            keyInfo = (new StringBuilder()).append(keyInfo).append("\n\tTN Partner :").append(tnLicenses != -1 ? Integer.toString(tnLicenses) : "unlimited").toString();
        else
        if(isType(TN_SERVER))
            keyInfo = (new StringBuilder()).append(keyInfo).append("\n\tTN Server :").append(tnLicenses != -1 ? Integer.toString(tnLicenses) : "unlimited").toString();
        return keyInfo;
    }

    public static void setKey(String key)
    {
    	Calendar calTime = Calendar.getInstance();
    	calTime.set(Calendar.YEAR, 2099);
    	calTime.set(Calendar.MONTH, 11);
    	calTime.set(Calendar.DATE, 30);
        try
        {
            Thread.currentThread();
            Thread.sleep(1000L);
        }
        catch(Exception e) { }
        if(key == null || key.length() < 12)
        {
            cust_id = -1;
            seq_id = -1;
            type = NO_KEY;
            licenses = 2;
            expires = calTime.getTime();
        }
        try
        {
            byte b[] = getKeyBytes(key);
            if(b == null)
                throw new ClientException(ClientExceptionBundle.class, ClientExceptionBundle.KEYINFO_INVALID_KEY, "");
            byte c[] = new byte[2];
            byte s[] = new byte[2];
            byte t[] = new byte[2];
            byte l[] = new byte[2];
            byte d[] = new byte[3];
            System.arraycopy(b, 0, c, 0, 2);
            System.arraycopy(b, 2, s, 0, 2);
            System.arraycopy(b, 4, t, 0, 2);
            System.arraycopy(b, 6, l, 0, 2);
            System.arraycopy(b, 8, d, 0, 3);
            cust_id = byteToInt2(c);
            seq_id = byteToInt2(s);
            type = byteToInt2(t);
            licenses = byteToInt2(l);
            if(isType(TN_SERVER))
                computeTNLicenses(d);
            short year = d[2];
            if(year < 0)
                year += 256;
            Calendar cal = Calendar.getInstance(TimeZone.getDefault(), Locale.US);
            cal.set(year + 1900, d[1], d[0], 0, 0, 0);
            expires = calTime.getTime();
        }
        catch(Exception e)
        {
            cust_id = -1;
            seq_id = -1;
            type = NO_KEY;
            licenses = 2;
            expires = calTime.getTime();
        }
    }

    protected static void computeTNLicenses(byte b[])
    {
        if((b[0] & 2) == 2)
        {
            tnLicenses = -1;
        } else
        {
            byte nibble = (byte)((b[0] & 0xc0) >> 6);
            int multiplier = 1;
            if(nibble == 1)
                multiplier = 10;
            else
            if(nibble == 2)
                multiplier = 100;
            else
            if(nibble == 3)
                multiplier = 1000;
            int number = (b[0] & 0x3f) >>> 2;
            tnLicenses = number * multiplier;
        }
        byte month = (byte)(b[1] & 0xf);
        byte day = (byte)((b[1] & 0xf0) >> 4 | (b[0] & 1) << 4);
        b[0] = day;
        b[1] = month;
    }

    protected static int checksum(byte b[])
    {
        int ck = 0;
        for(int i = 0; i < b.length; i++)
            ck = ck * b[i] + 1;

        return ck & 0xffff;
    }

    protected static int checksum2(byte b[])
    {
        int ck = 13;
        for(int i = 0; i < b.length; i++)
            ck = ck * ck * b[i] * b[i] * 13 + 11;

        return ck & 0xffff;
    }

    protected static int byteToInt2(byte b[])
    {
        if(b == null || b.length != 2)
            return -1;
        else
            return b[0] & 0xff | (b[1] & 0xff) << 8;
    }

    protected static byte[] getKeyBytes(String key)
    {
        if(key == null)
            return null;
        StringBuffer sb = new StringBuffer();
        key = key.toUpperCase();
        for(int i = 0; i < key.length(); i++)
            if(key.charAt(i) != ' ')
                sb.append(key.charAt(i));

        key = byteUnMap(EncUtil.getNetBytes(sb.toString()));
        if(key.length() < 26)
            return null;
        byte rbs[] = EncUtil.getNetBytes(key.substring(0, 4));
        byte kbs[] = EncUtil.getNetBytes(key.substring(4, 22));
        byte cbs[] = EncUtil.getNetBytes(key.substring(22, 26));
        ExtBitSet nrbs = new ExtBitSet(rbs, 5, 8);
        ExtBitSet nkbs = new ExtBitSet(kbs, 5, 8);
        nkbs.xor(nrbs);
        byte kbytes[] = nkbs.getBytes(8);
        ExtBitSet ncbs = new ExtBitSet(cbs, 5, 8);
        int cksum = byteToInt2(ncbs.getBytes(8));
        if(cksum != checksum(kbytes) && cksum != checksum2(kbytes))
            return null;
        else
            return kbytes;
    }

    protected static String byteUnMap(byte b[])
    {
        StringBuffer sb = new StringBuffer(b.length);
        for(int i = 0; i < b.length; i++)
        {
            int j;
            for(j = 0; j < cmap.length && b[i] != cmap[j]; j++);
            if(j != cmap.length)
                sb.append((char)j);
        }

        return sb.toString();
    }

    public static int NO_KEY;
    public static int SERVER_B2B = 1;
    public static int TOOLKIT = 2;
    public static int TOOLKIT_PRO = 4;
    public static int PARTNER = 8;
    public static int BEEFCAKE = 16;
    public static int TN_SERVER = 32;
    public static int OEM = 64;
    public static int UNUSED3 = 128;
    public static int PACKAGE = 256;
    public static final int TN_UNLIMITED = -1;
    public static final int IS_UNLIMITED = 0;
    protected static Random rand = new Random();
    protected static final byte cmap[] = {
        65, 66, 67, 68, 69, 70, 71, 72, 56, 74, 
        75, 76, 77, 57, 80, 81, 82, 83, 84, 85, 
        86, 87, 88, 89, 90, 49, 50, 51, 52, 53, 
        54, 55
    };
    protected static int cust_id = -1;
    protected static int seq_id = -1;
    protected static int type;
    protected static int licenses = 2;
    protected static Date expires;
    protected static int tnLicenses = 0;

    static 
    {
        NO_KEY = 0;
        type = NO_KEY;
    }
}
