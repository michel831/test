import org.paukov.combinatorics.Factory;
import org.paukov.combinatorics.Generator;
import org.paukov.combinatorics.ICombinatoricsVector;

public class TestHello {

	private static final Character[] STRS = { '0', '1', '2', '3', '4', '5',
			'6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I',
			'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
			'W', 'X', 'Y', 'Z' };

	public static void main(String[] args) {
		ICombinatoricsVector<Character> originalVector = Factory
				.createVector(STRS);

		Generator<Character> gen = Factory
				.createPermutationWithRepetitionGenerator(originalVector, 6);
		
		System.out.println(gen.generateAllObjects().size());
		
	}
}
