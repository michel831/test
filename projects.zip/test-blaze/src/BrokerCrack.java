import java.io.IOException;

import org.paukov.combinatorics.Factory;
import org.paukov.combinatorics.Generator;
import org.paukov.combinatorics.ICombinatoricsVector;

public class BrokerCrack {

	private static final Character[] STRS = { '0', '1', '2', '3', '4', '5',
			'6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I',
			'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
			'W', 'X', 'Y', 'Z' };

	public static void main(String[] args) throws IOException,
			InterruptedException {

		Runtime rt = Runtime.getRuntime();

		ICombinatoricsVector<Character> originalVector = Factory
				.createVector(STRS);

		Generator<Character> gen = Factory
				.createPermutationWithRepetitionGenerator(originalVector, 6);
		
		String[] cmdString = {
				"cmd",
				"/c",
				"C:\\HOMEWARE\\webMethods7\\Broker\\bin\\server_config.exe",
				"create",
				"C:\\HOMEWARE\\webMethods7\\data\\awbrokers71\\default",
				"-k", "" };
		
		// Print the result
		for (ICombinatoricsVector<Character> perm : gen) {
			
//			long l = System.currentTimeMillis();
			
			StringBuilder sb = new StringBuilder(
					"BKR7XX-S10000-MB-C10000-2AMJ-");

			sb.append(perm.getValue(0)).append(perm.getValue(1)).append(
					perm.getValue(2)).append(perm.getValue(3)).append(
					perm.getValue(4)).append(perm.getValue(5));

			// sb.append(perm.getValue(0)).append(perm.getValue(1)).append(
			// perm.getValue(2)).append(perm.getValue(3)).append('-')
			// .append(perm.getValue(4)).append(perm.getValue(5)).append(
			// perm.getValue(6)).append(perm.getValue(7)).append(
			// perm.getValue(8)).append(perm.getValue(9));

			// sb.append(perm.getValue(0)).append(perm.getValue(1)).append(
			// perm.getValue(2)).append('-').append(perm.getValue(3))
			// .append(perm.getValue(4)).append(perm.getValue(5)).append(
			// perm.getValue(6)).append(perm.getValue(7)).append(
			// perm.getValue(8)).append('-').append(
			// perm.getValue(9)).append(perm.getValue(10)).append(
			// '-').append(perm.getValue(11)).append(
			// perm.getValue(12)).append(perm.getValue(13))
			// .append(perm.getValue(14)).append(perm.getValue(15))
			// .append(perm.getValue(16)).append('-').append(
			// perm.getValue(17)).append(perm.getValue(18))
			// .append(perm.getValue(19)).append(perm.getValue(20))
			// .append('-').append(perm.getValue(21)).append(
			// perm.getValue(22)).append(perm.getValue(23))
			// .append(perm.getValue(24)).append(perm.getValue(25))
			// .append(perm.getValue(26));
			cmdString[cmdString.length - 1] = sb.toString();
			Process pr = rt.exec(cmdString);
//			System.err.println(sb.toString());
			// BufferedReader input = new BufferedReader(new
			// InputStreamReader(pr
			// .getInputStream()));
			//
			// String line = null;

			// while ((line = input.readLine()) != null) {
			// System.out.println(line);
			// }

			int exitVal = pr.waitFor();
			if (exitVal != 38) {
				System.out.println(sb.toString());
			}
//			long l1 = System.currentTimeMillis();
//			System.out.println(l1-l);
		}

	}
}
