import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class VioCrack {

	private static final char[] STRS = { '0', '1', '2', '3', '4', '5', '6',
			'7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
			'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W',
			'X', 'Y', 'Z' };

	public static void main(String[] args) throws IOException, InterruptedException {
		Runtime rt = Runtime.getRuntime();
//        //Process pr = rt.exec("cmd /c dir");
//		
//		StringBuilder lic = new StringBuilder("000-000000-00-000000-0000-000000");
//		for (int i = lic.length() - 1; i >= 0; i--) {
//			if (lic.charAt(i) != '-') {
//				for (char s : STRS) {
//					lic.setCharAt(i, s);
//					if (i != lic.length() - 1) {
//						for (int j = lic.length() - 1 ; j > i; j--) {
//							for (char c : STRS) {
//								lic.setCharAt(j, c);
//								System.out.println(lic.toString());
//							}
//						}
//					}
//					System.out.println(lic.toString());
//				}
//				lic.setCharAt(i, '0');
//			}
//		}
		
		String[] cmdString = {"cmd", "/c", "C:\\HOMEWARE\\webMethods7\\Broker\\bin\\server_config.exe", "create", "C:\\HOMEWARE\\webMethods7\\data\\awbrokers71\\default", "-k", "BKR6XX-S10000-MB-C10000-29PG-G7F9QG"};
        
		long l = System.currentTimeMillis();
		Process pr = rt.exec(cmdString);
        BufferedReader input = new BufferedReader(new InputStreamReader(
                pr.getInputStream()));

//          String line = null;
//
//          while ((line = input.readLine()) != null)
//          {
//             System.out.println(line);
//          }

          int exitVal = pr.waitFor();
          System.out.println("Exited with error code " + exitVal);
          long l1 = System.currentTimeMillis();
          System.out.println(l1-l);
	}
	
	private static void modify (StringBuilder sb) {
		for (int i = sb.length() - 1; i >= 0; i--) {
			if (sb.charAt(i) != '-') {
				char c = sb.charAt(i);
				if (c != 'Z') {
					int index = Arrays.binarySearch(STRS, c);
//					sb.setCharAt(i, ch);
				} else {
					
				}
			}
		}
	}
	
}
