
public class TestNull {

	public static void main(String[] args) {
		if (null == null) {
			System.out.println("aaaa");
		}
	}
	
}
