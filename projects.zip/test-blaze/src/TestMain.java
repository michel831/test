import java.math.BigInteger;


public class TestMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		System.out.println(WjHzFyL.WjHFxBD(12, "12-1-1-0-8JXXB7PZKCHCB-139881-06032013"));
//		System.out.println(WjHzFyL.WjHFxBD(11, "11-1-1-0-BJ62ARKZKZMP8-139881-06032013"));
		
		System.out.println(new BigInteger((new BigInteger("1")).toString(2), 2));
		System.out.println(new BigInteger("1", 36));
		System.out.println(new BigInteger("0", 36));
		
		BigInteger biginteger = new BigInteger((new BigInteger("1")).toString(2), 2);
        BigInteger biginteger1 = new BigInteger("1", 36);
        BigInteger biginteger2 = new BigInteger("0", 36);
		
		int j = Integer.valueOf("12").intValue() * 0x5f5e101;
        j += biginteger.intValue() * 0xd2fc9;
        j += biginteger1.intValue() * 111;
        j += biginteger2.intValue() * 0x1e1d7f;
        j += Integer.valueOf("139881").intValue() * 13579;
        j += Integer.valueOf("06032020").intValue() * 479;
        j = (j & 0xf0000000) >>> 28 | (j & 0xf) << 28 | j & 0xf000000 | j & 0xf0 | (j & 0xf00000) >>> 12 | (j & 0xf00) << 12 | j & 0xf0000 | j & 0xf000;
        long l = (long)(j ^ 0x13572468) << 32 | (long)(j ^ 0xabadcafe) & 0xffffffffL;
        System.out.println(j);
        System.out.println(l);
        StringBuffer stringbuffer = new StringBuffer();
        
        for(int k = 0; k < 13; k++)
        {
            stringbuffer.append(WjHzFnP[(int)(l & 31L)]);
            l >>>= 5;
        }

        String s8 = stringbuffer.toString();
        System.out.println(s8);
        
	}
	
	private static char WjHzFnP[] = {
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 
        'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'U', 
        'X', 'Z'
    };

}
