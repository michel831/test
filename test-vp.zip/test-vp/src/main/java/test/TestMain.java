package test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.params.ConnRoutePNames;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.dom4j.DocumentException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class TestMain {

	/**
	 * @param args
	 * @throws IOException
	 * @throws DocumentException
	 * @throws IllegalStateException
	 */
	public static void main(String[] args) throws IOException, IllegalStateException {
		HttpHost proxy = new HttpHost("proxy.fr.world.socgen", 8080, "http");
		DefaultHttpClient client = new DefaultHttpClient();
		client.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY, proxy);
		client.getCredentialsProvider().setCredentials(
				  new AuthScope("proxy.fr.world.socgen", 8080),
				  new UsernamePasswordCredentials("xiaojun.ma-ext@sgcib.com", "Vivi1118"));
		HttpGet request = new HttpGet("https://secure.fr.vente-privee.com/vp4/Login/Portal_FR.aspx");
		HttpResponse response = client.execute(request);
		
		String cookies = response.getFirstHeader("Set-Cookie") == null ? "" : 
            response.getFirstHeader("Set-Cookie").toString();
		
		System.out.println(cookies);
		
//		Scanner sc = new Scanner(response.getEntity().getContent());
//		while (sc.hasNextLine()) {
//			System.out.println(sc.nextLine());
//		}
		
//		SAXReader reader = new SAXReader(false);
//		reader.setEntityResolver(new IgnoreDTDEntityResolver());
//        Document document = reader.read(response.getEntity().getContent());
//        Node node = document.selectSingleNode("//form");
//        System.out.println(node.getStringValue());
		
		Document document = Jsoup.parse(response.getEntity().getContent(), "UTF-8", "");
		Element formElement = document.getElementById("aspnet_form");
		Element viewStateElement = document.getElementById("__VIEWSTATE");
		Element eventValidationElement = document.getElementById("__EVENTVALIDATION");
		
//		System.err.println(formElement.attr("action"));
//		System.err.println(viewStateElement.attr("value"));
//		System.err.println(eventValidationElement.attr("value"));
		
		HttpPost  post = new HttpPost(formElement.attr("action"));
		
		post.setHeader("Host", "secure.fr.vente-privee.com");
		post.setHeader("User-Agent", "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.10) Gecko/2009042316 Firefox/3.0.10 (.NET CLR 3.5.30729)");
		post.setHeader("Accept", 
	             "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
		post.setHeader("Accept-Language", "en-US,en;q=0.5");
		post.setHeader("Accept-Encoding", "gzip,deflate");
		post.setHeader("Accept-Charset", "ISO-8859-1,utf-8;q=0.7,*;q=0.7");
		post.setHeader("Keep-Alive", "300");
		post.setHeader("Connection", "keep-alive");
		post.setHeader("Referer", "https://secure.fr.vente-privee.com/vp4/Login/Portal_FR.aspx");
		post.setHeader("Content-Type", "application/x-www-form-urlencoded");
		post.setHeader("Cookie", cookies);
		
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(5);
		nameValuePairs.add(new BasicNameValuePair("__VIEWSTATE", viewStateElement.attr("value")));
		nameValuePairs.add(new BasicNameValuePair("__EVENTVALIDATION", eventValidationElement.attr("value")));
		nameValuePairs.add(new BasicNameValuePair("txtEmail", "349678649@qq.com"));
		nameValuePairs.add(new BasicNameValuePair("txtPassword", "123321"));
		nameValuePairs.add(new BasicNameValuePair("btSubmit", "OK"));
		post.setEntity(new UrlEncodedFormEntity(nameValuePairs));
		
		
		
		HttpResponse responseLogin = client.execute(post);
//		Document documentLoginResp = Jsoup.parse(responseLogin.getEntity().getContent(), "UTF-8", "");
//		documentLoginResp.
		Scanner sc = new Scanner(responseLogin.getEntity().getContent());
		while (sc.hasNextLine()) {
			System.out.println(sc.nextLine());
		}

		
		HttpGet requestDefault = new HttpGet("https://secure.fr.vente-privee.com/vp4/home/Default.aspx");
		HttpResponse responseHome = client.execute(requestDefault);

		Document documentHome = Jsoup.parse(responseHome.getEntity().getContent(), "UTF-8", "");
		Elements formElements = documentHome.getElementsByTag("h4");
		Element venteElement = null;
		for (int i = 0 ; i < formElements.size(); i++) {
			if ("Festina".equalsIgnoreCase(formElements.get(i).text())) {
				venteElement = formElements.get(i);
				break;
			}
		}
		Element elementLink = venteElement.parent();
		System.out.println(elementLink.attr("href"));
		HttpGet requestVente = new HttpGet("https://secure.fr.vente-privee.com" + elementLink.attr("href"));
		HttpResponse responseVente = client.execute(requestVente);
		Scanner sc1 = new Scanner(responseVente.getEntity().getContent());
		while (sc1.hasNextLine()) {
			System.out.println(sc1.nextLine());
		}
		
		
		HttpPost  postBuy = new HttpPost("http://fr.vente-privee.com/cart/CartServices/AddToCartOrCanBeReopened");
		
		postBuy.setHeader("User-Agent", "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.10) Gecko/2009042316 Firefox/3.0.10 (.NET CLR 3.5.30729)");
		postBuy.setHeader("Accept", "*/*");
		postBuy.setHeader("Accept-Language", "en-US,en;q=0.5");
		postBuy.setHeader("Accept-Encoding", "gzip,deflate");
		postBuy.setHeader("Accept-Charset", "ISO-8859-1,utf-8;q=0.7,*;q=0.7");
		postBuy.setHeader("Keep-Alive", "300");
		postBuy.setHeader("X-Requested-With", "XMLHttpRequest");
		postBuy.setHeader("Proxy-Connection", "keep-alive");
		postBuy.setHeader("Referer", "https://secure.fr.vente-privee.com/vp4/Login/Portal_FR.aspx");
		postBuy.setHeader("Cache-Control", "no-cache");
		
		List<NameValuePair> nameValuePairsBuy = new ArrayList<NameValuePair>(3);
		nameValuePairsBuy.add(new BasicNameValuePair("productFamilyId", "fnPQg0I29+aNU9hF2mPAnA=="));
		nameValuePairsBuy.add(new BasicNameValuePair("productId", "xvZLHOrdEps5/iyhwUGDng=="));
		nameValuePairsBuy.add(new BasicNameValuePair("quantity", "1"));
		postBuy.setEntity(new UrlEncodedFormEntity(nameValuePairsBuy));
		
		HttpResponse responseBuy = client.execute(postBuy);
//		Document documentLoginResp = Jsoup.parse(responseLogin.getEntity().getContent(), "UTF-8", "");
//		documentLoginResp.
		Scanner sc2 = new Scanner(responseBuy.getEntity().getContent());
		while (sc2.hasNextLine()) {
			System.out.println(sc2.nextLine());
		}

	}
}
