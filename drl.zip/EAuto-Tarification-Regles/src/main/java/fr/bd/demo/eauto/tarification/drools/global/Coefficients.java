package fr.bd.demo.eauto.tarification.drools.global;


public class Coefficients {

	private double coeffASS = 1d;
	private double coeffBG = 1d;
	private double coeffCANAT = 1d;
	private double coeffDOMMAGETTACCID = 1d;
	private double coeffDPRSA = 1d;
	private double coeffIV = 1d;
	private double coeffRC = 1d;
	private double coeffSDC450 = 1d;
	private double coeffSDC800 = 1d;
	private double coeffREMPLACEMENTVEHIC = 1d;
	
	public double getCoeffASS() {
		return coeffASS;
	}
	public void setCoeffASS(double coeffASS) {
		this.coeffASS = coeffASS;
	}
	public double getCoeffBG() {
		return coeffBG;
	}
	public void setCoeffBG(double coeffBG) {
		this.coeffBG = coeffBG;
	}
	public double getCoeffCANAT() {
		return coeffCANAT;
	}
	public void setCoeffCANAT(double coeffCANAT) {
		this.coeffCANAT = coeffCANAT;
	}
	public double getCoeffDOMMAGETTACCID() {
		return coeffDOMMAGETTACCID;
	}
	public void setCoeffDOMMAGETTACCID(double coeffDOMMAGETTACCID) {
		this.coeffDOMMAGETTACCID = coeffDOMMAGETTACCID;
	}
	public double getCoeffDPRSA() {
		return coeffDPRSA;
	}
	public void setCoeffDPRSA(double coeffDPRSA) {
		this.coeffDPRSA = coeffDPRSA;
	}
	public double getCoeffIV() {
		return coeffIV;
	}
	public void setCoeffIV(double coeffIV) {
		this.coeffIV = coeffIV;
	}
	public double getCoeffRC() {
		return coeffRC;
	}
	public void setCoeffRC(double coeffRC) {
		this.coeffRC = coeffRC;
	}
	public double getCoeffSDC450() {
		return coeffSDC450;
	}
	public void setCoeffSDC450(double coeffSDC450) {
		this.coeffSDC450 = coeffSDC450;
	}
	public double getCoeffSDC800() {
		return coeffSDC800;
	}
	public void setCoeffSDC800(double coeffSDC800) {
		this.coeffSDC800 = coeffSDC800;
	}
	public double getCoeffREMPLACEMENTVEHIC() {
		return coeffREMPLACEMENTVEHIC;
	}
	public void setCoeffREMPLACEMENTVEHIC(double coeffREMPLACEMENTVEHIC) {
		this.coeffREMPLACEMENTVEHIC = coeffREMPLACEMENTVEHIC;
	}
	
}
