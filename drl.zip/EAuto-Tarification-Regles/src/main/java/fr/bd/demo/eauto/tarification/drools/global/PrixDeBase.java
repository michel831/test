package fr.bd.demo.eauto.tarification.drools.global;

public class PrixDeBase {

	private double prixASS;
	private double prixBG;
	private double prixCANAT;
	private double prixDOMMAGETTACCID;
	private double prixDPRSA;
	private double prixIV;
	private double prixRC;
	private double prixSDC450;
	private double prixSDC800;
	private double prixREMPLACEMENTVEHIC;
	
	public double getPrixASS() {
		return prixASS;
	}
	public void setPrixASS(double prixASS) {
		this.prixASS = prixASS;
	}
	public double getPrixBG() {
		return prixBG;
	}
	public void setPrixBG(double prixBG) {
		this.prixBG = prixBG;
	}
	public double getPrixCANAT() {
		return prixCANAT;
	}
	public void setPrixCANAT(double prixCANAT) {
		this.prixCANAT = prixCANAT;
	}
	public double getPrixDOMMAGETTACCID() {
		return prixDOMMAGETTACCID;
	}
	public void setPrixDOMMAGETTACCID(double prixDOMMAGETTACCID) {
		this.prixDOMMAGETTACCID = prixDOMMAGETTACCID;
	}
	public double getPrixDPRSA() {
		return prixDPRSA;
	}
	public void setPrixDPRSA(double prixDPRSA) {
		this.prixDPRSA = prixDPRSA;
	}
	public double getPrixIV() {
		return prixIV;
	}
	public void setPrixIV(double prixIV) {
		this.prixIV = prixIV;
	}
	public double getPrixRC() {
		return prixRC;
	}
	public void setPrixRC(double prixRC) {
		this.prixRC = prixRC;
	}
	public double getPrixSDC450() {
		return prixSDC450;
	}
	public void setPrixSDC450(double prixSDC450) {
		this.prixSDC450 = prixSDC450;
	}
	public double getPrixSDC800() {
		return prixSDC800;
	}
	public void setPrixSDC800(double prixSDC800) {
		this.prixSDC800 = prixSDC800;
	}
	public double getPrixREMPLACEMENTVEHIC() {
		return prixREMPLACEMENTVEHIC;
	}
	public void setPrixREMPLACEMENTVEHIC(double prixREMPLACEMENTVEHIC) {
		this.prixREMPLACEMENTVEHIC = prixREMPLACEMENTVEHIC;
	}
	
}
