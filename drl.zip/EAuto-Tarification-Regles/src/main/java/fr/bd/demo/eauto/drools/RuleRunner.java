package fr.bd.demo.eauto.drools;

import org.drools.KnowledgeBase;
import org.drools.runtime.StatefulKnowledgeSession;

public class RuleRunner {

	private StatefulKnowledgeSession ksession;

	private KnowledgeBase kbase;

	public KnowledgeBase getKbase() {
		return kbase;
	}

	public void setKbase(KnowledgeBase kbase) {
		this.kbase = kbase;
	}

	public StatefulKnowledgeSession getKsession() {
		return ksession;
	}

	public void setKsession(StatefulKnowledgeSession ksession) {
		this.ksession = ksession;
	}
}
