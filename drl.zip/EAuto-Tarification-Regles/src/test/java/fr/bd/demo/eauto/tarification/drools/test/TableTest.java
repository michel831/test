package fr.bd.demo.eauto.tarification.drools.test;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.drools.KnowledgeBase;
import org.drools.event.rule.DebugAgendaEventListener;
import org.drools.event.rule.DebugWorkingMemoryEventListener;
import org.drools.runtime.StatefulKnowledgeSession;
import org.drools.runtime.rule.impl.AgendaImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import fr.bd.demo.eauto.tarification.drools.global.Coefficients;
import fr.bd.demo.eauto.tarification.drools.global.PrixDeBase;
import fr.bd.demo.metier.object.auto.ContratAssurance;
import fr.bd.demo.metier.object.auto.PersonnePhysique;
import fr.bd.demo.metier.object.auto.SpecificationVehiculeTerrestre;
import fr.bd.demo.metier.object.auto.SpecificiteMoteur;
import fr.bd.demo.metier.object.auto.Voiture;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration( { "classpath:spring-tarification-config.xml" })
public class TableTest {
	
	@Autowired
	private KnowledgeBase kbase;
	
	@Test
	public void testStatefulCalculation() throws ParseException {
		StatefulKnowledgeSession statefulSession = kbase.newStatefulKnowledgeSession();
		statefulSession.addEventListener( new DebugAgendaEventListener() );
		statefulSession.addEventListener( new DebugWorkingMemoryEventListener() );
		statefulSession.setGlobal("coefficients", new Coefficients());
		statefulSession.setGlobal("prixDeBase", new PrixDeBase());
		statefulSession.setGlobal("dateEffet", new SimpleDateFormat("dd/MM/yyyy").parse("12/12/2012"));
		SpecificationVehiculeTerrestre specificationVehiculeTerrestre = new SpecificationVehiculeTerrestre();
		specificationVehiculeTerrestre.setTypeCarosserie("BERLINE");
		statefulSession.insert(specificationVehiculeTerrestre);
		
		SpecificiteMoteur specificiteMoteur = new SpecificiteMoteur();
		specificiteMoteur.setTypeCarburant("ESSENCE");
		specificiteMoteur.setPuissanceCV(62);
		statefulSession.insert(specificiteMoteur);
		
		Voiture voiture = new Voiture();
		voiture.setDate1ErMiseEnCirculation(new SimpleDateFormat("dd/MM/yyyy").parse("01/12/2012"));
		statefulSession.insert(voiture);
		statefulSession.insert(new ContratAssurance());
		
		PersonnePhysique personnePhysique = new PersonnePhysique();
		personnePhysique.setDateNaissance(new SimpleDateFormat("dd/MM/yyyy").parse("01/12/1983"));
		statefulSession.insert(personnePhysique);
		((AgendaImpl)statefulSession.getAgenda()).activateRuleFlowGroup("calculation");
		statefulSession.fireAllRules();
		assertEquals(0.98 * 0.85 * 1.1, ((Coefficients)statefulSession.getGlobal("coefficients")).getCoeffRC(), 0);
		assertEquals(0.98 * 0.85 * 1.1, ((Coefficients)statefulSession.getGlobal("coefficients")).getCoeffBG(), 0);
		assertEquals(0.98 * 0.85 * 1.1, ((Coefficients)statefulSession.getGlobal("coefficients")).getCoeffASS(), 0);
		statefulSession.dispose();
	}
	

}
