package fr.bd.demo.eauto.tarification.drools.test;

import static org.junit.Assert.assertEquals;

import org.drools.KnowledgeBase;
import org.drools.event.rule.DebugAgendaEventListener;
import org.drools.event.rule.DebugWorkingMemoryEventListener;
import org.drools.runtime.StatefulKnowledgeSession;
import org.drools.runtime.rule.impl.AgendaImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import fr.bd.demo.eauto.tarification.drools.global.PrixDeBase;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration( { "classpath:spring-init-config.xml" })
public class InitTableTest {
	
	@Autowired
	private KnowledgeBase kbase;
	
	@Test
	public void testStatefulInit() {
		StatefulKnowledgeSession statefulSession = kbase.newStatefulKnowledgeSession();
		statefulSession.addEventListener( new DebugAgendaEventListener() );
		statefulSession.addEventListener( new DebugWorkingMemoryEventListener() );
		statefulSession.setGlobal("prixDeBase", new PrixDeBase());
		((AgendaImpl)statefulSession.getAgenda()).activateRuleFlowGroup("init");
		statefulSession.fireAllRules();
		assertEquals(20, ((PrixDeBase)statefulSession.getGlobal("prixDeBase")).getPrixASS(), 0);
		statefulSession.dispose();
	}
	

}
