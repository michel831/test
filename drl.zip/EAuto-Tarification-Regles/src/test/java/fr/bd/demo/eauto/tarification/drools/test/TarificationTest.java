package fr.bd.demo.eauto.tarification.drools.test;
import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.drools.KnowledgeBase;
import org.drools.command.Command;
import org.drools.command.CommandFactory;
import org.drools.command.runtime.process.StartProcessCommand;
import org.drools.event.rule.DebugAgendaEventListener;
import org.drools.event.rule.DebugWorkingMemoryEventListener;
import org.drools.logger.KnowledgeRuntimeLogger;
import org.drools.logger.KnowledgeRuntimeLoggerFactory;
import org.drools.runtime.StatefulKnowledgeSession;
import org.drools.runtime.StatelessKnowledgeSession;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import fr.bd.demo.eauto.tarification.drools.global.Coefficients;
import fr.bd.demo.eauto.tarification.drools.global.PrixDeBase;
import fr.bd.demo.metier.object.Prime;
import fr.bd.demo.metier.object.auto.ContratAssurance;
import fr.bd.demo.metier.object.auto.GarantieSouscrite;
import fr.bd.demo.metier.object.auto.OptionSouscrite;
import fr.bd.demo.metier.object.auto.PersonnePhysique;
import fr.bd.demo.metier.object.auto.SpecificationVehiculeTerrestre;
import fr.bd.demo.metier.object.auto.SpecificiteMoteur;
import fr.bd.demo.metier.object.auto.Voiture;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration( { "classpath:spring-tarification-config.xml" })
public class TarificationTest {
	
	@Autowired
	private KnowledgeBase kbase;
	
	@Test
	public void testStatefulTarification() throws ParseException {
		StatefulKnowledgeSession statefulSession = kbase.newStatefulKnowledgeSession();
		statefulSession.addEventListener( new DebugAgendaEventListener() );
		statefulSession.addEventListener( new DebugWorkingMemoryEventListener() );
		
		KnowledgeRuntimeLogger logger = KnowledgeRuntimeLoggerFactory.newFileLogger(statefulSession, "log/tarif");
		statefulSession.setGlobal("coefficients", new Coefficients());
		statefulSession.setGlobal("prixDeBase", new PrixDeBase());
		statefulSession.setGlobal("dateEffet", new SimpleDateFormat("dd/MM/yyyy").parse("12/12/2012"));
		SpecificationVehiculeTerrestre specificationVehiculeTerrestre = new SpecificationVehiculeTerrestre();
		specificationVehiculeTerrestre.setTypeCarosserie("BERLINE");
		statefulSession.insert(specificationVehiculeTerrestre);
		
		SpecificiteMoteur specificiteMoteur = new SpecificiteMoteur();
		specificiteMoteur.setTypeCarburant("ESSENCE");
		specificiteMoteur.setPuissanceCV(62);
		statefulSession.insert(specificiteMoteur);
		
		Voiture voiture = new Voiture();
		voiture.setDate1ErMiseEnCirculation(new SimpleDateFormat("dd/MM/yyyy").parse("01/12/2010"));
		statefulSession.insert(voiture);
		
		ContratAssurance contratAssurance = new ContratAssurance();
		GarantieSouscrite garantie = new GarantieSouscrite();
		garantie.setCodeGarantie("ASS");
		garantie.setPrime(new Prime());
		contratAssurance.getComposantContrat().add(garantie);
		
		GarantieSouscrite garantie1 = new GarantieSouscrite();
		garantie1.setCodeGarantie("BG");
		garantie1.setPrime(new Prime());
		contratAssurance.getComposantContrat().add(garantie1);
		
		OptionSouscrite optionSouscrite = new OptionSouscrite();
		contratAssurance.getComposantContrat().add(optionSouscrite);
		statefulSession.insert(contratAssurance);
		
		PersonnePhysique personnePhysique = new PersonnePhysique();
		personnePhysique.setDateNaissance(new SimpleDateFormat("dd/MM/yyyy").parse("01/12/1983"));
		statefulSession.insert(personnePhysique);
		statefulSession.startProcess("fr.bd.demo.drools.tarification");
		statefulSession.fireAllRules();

		assertEquals(16.4934, garantie.getPrime().getTTC(), 0);
		assertEquals(20.61675, garantie1.getPrime().getTTC(), 0);
		assertEquals(37.11015, optionSouscrite.getPrime().getTTC(), 0.0000001);
		assertEquals(37.11015, contratAssurance.getPrime().getTTC(), 0.0000001);
		logger.close();
		statefulSession.dispose();
	}
	
	@Test
	public void testStatelessTarification() throws ParseException {
		StatelessKnowledgeSession statelessSession = kbase.newStatelessKnowledgeSession();
		statelessSession.addEventListener( new DebugAgendaEventListener() );
		statelessSession.addEventListener( new DebugWorkingMemoryEventListener() );
		List<Command<?>> list = new ArrayList<Command<?>>();
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("nom", "EAuto");
		params.put("produit", null);
		list.add(CommandFactory.newSetGlobal("coefficients", new Coefficients(), true));
		list.add(CommandFactory.newSetGlobal("prixDeBase", new PrixDeBase(), true));
		list.add(CommandFactory.newSetGlobal("dateEffet", new SimpleDateFormat("dd/MM/yyyy").parse("12/12/2012"), false));
		
	
		SpecificationVehiculeTerrestre specificationVehiculeTerrestre = new SpecificationVehiculeTerrestre();
		specificationVehiculeTerrestre.setTypeCarosserie("BERLINE");
		
		SpecificiteMoteur specificiteMoteur = new SpecificiteMoteur();
		specificiteMoteur.setTypeCarburant("ESSENCE");
		specificiteMoteur.setPuissanceCV(62);
		
		Voiture voiture = new Voiture();
		voiture.setDate1ErMiseEnCirculation(new SimpleDateFormat("dd/MM/yyyy").parse("01/12/2010"));
		
		ContratAssurance contratAssurance = new ContratAssurance();
		GarantieSouscrite garantie = new GarantieSouscrite();
		garantie.setCodeGarantie("ASS");
		garantie.setPrime(new Prime());
		contratAssurance.getComposantContrat().add(garantie);
		
		GarantieSouscrite garantie1 = new GarantieSouscrite();
		garantie1.setCodeGarantie("BG");
		garantie1.setPrime(new Prime());
		contratAssurance.getComposantContrat().add(garantie1);
		
		OptionSouscrite optionSouscrite = new OptionSouscrite();
		contratAssurance.getComposantContrat().add(optionSouscrite);
		
		PersonnePhysique personnePhysique = new PersonnePhysique();
		personnePhysique.setDateNaissance(new SimpleDateFormat("dd/MM/yyyy").parse("01/12/1983"));
		
		list.add(CommandFactory.newInsert(specificationVehiculeTerrestre));
		list.add(CommandFactory.newInsert(specificiteMoteur));
		list.add(CommandFactory.newInsert(voiture));
		list.add(CommandFactory.newInsert(contratAssurance, "contrat"));
		list.add(CommandFactory.newInsert(personnePhysique));
		list.add(new StartProcessCommand("fr.bd.demo.drools.tarification"));
		statelessSession.execute(CommandFactory.newBatchExecution(list));
		assertEquals(16.4934, garantie.getPrime().getTTC(), 0);
		assertEquals(20.61675, garantie1.getPrime().getTTC(), 0);
		assertEquals(37.11015, optionSouscrite.getPrime().getTTC(), 0.0000001);
		assertEquals(37.11015, contratAssurance.getPrime().getTTC(), 0.0000001);
	}

}
