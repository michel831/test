package fr.bd.demo.eauto.tarification.drools.test;

import java.text.ParseException;

import org.drools.KnowledgeBase;
import org.drools.event.rule.DebugAgendaEventListener;
import org.drools.event.rule.DebugWorkingMemoryEventListener;
import org.drools.runtime.StatefulKnowledgeSession;
import org.drools.runtime.rule.impl.AgendaImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import fr.bd.demo.eauto.tarification.drools.global.Coefficients;
import fr.bd.demo.eauto.tarification.drools.global.PrixDeBase;
import fr.bd.demo.metier.object.Prime;
import fr.bd.demo.metier.object.auto.ContratAssurance;
import fr.bd.demo.metier.object.auto.GarantieSouscrite;
import fr.bd.demo.metier.object.auto.OptionSouscrite;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration( { "classpath:spring-simple-config.xml" })
public class SimpleTest {
	
	@Autowired
	private KnowledgeBase kbase;
	
	@Test
	public void testStatefulFinalisation() throws ParseException {
		StatefulKnowledgeSession statefulSession = kbase.newStatefulKnowledgeSession();
		statefulSession.addEventListener( new DebugAgendaEventListener() );
		statefulSession.addEventListener( new DebugWorkingMemoryEventListener() );
		
		statefulSession.setGlobal("coefficients", new Coefficients());
		statefulSession.setGlobal("prixDeBase", new PrixDeBase());
		ContratAssurance contratAssurance = new ContratAssurance();
		GarantieSouscrite garantie = new GarantieSouscrite();
		garantie.setCodeGarantie("ASS");
		garantie.setPrime(new Prime());
		garantie.getPrime().setTTC(200);
		contratAssurance.getComposantContrat().add(garantie);
		
		GarantieSouscrite garantie1 = new GarantieSouscrite();
		garantie1.setCodeGarantie("BG");
		garantie1.setPrime(new Prime());
		garantie1.getPrime().setTTC(250);
		contratAssurance.getComposantContrat().add(garantie1);
		
		OptionSouscrite optionSouscrite = new OptionSouscrite();
		contratAssurance.getComposantContrat().add(optionSouscrite);
		statefulSession.insert(contratAssurance);
		((AgendaImpl)statefulSession.getAgenda()).activateRuleFlowGroup("finalisation");
		statefulSession.fireAllRules();
		
		statefulSession.dispose();
	}
	

}
