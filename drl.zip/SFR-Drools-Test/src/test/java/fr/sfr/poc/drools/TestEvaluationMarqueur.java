package fr.sfr.poc.drools;

import static org.junit.Assert.assertEquals;

import org.drools.KnowledgeBase;
import org.drools.command.assertion.AssertEquals;
import org.drools.event.rule.DebugAgendaEventListener;
import org.drools.event.rule.DebugWorkingMemoryEventListener;
import org.drools.runtime.StatefulKnowledgeSession;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import fr.bd.sfr.poc.sql.generator.Client;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration( { "classpath:spring-sfr-config.xml" })
public class TestEvaluationMarqueur {

	@Autowired
	private KnowledgeBase kbase;
	
	
	@Test
	public void test() {
		StatefulKnowledgeSession statefulSession = kbase.newStatefulKnowledgeSession();
		statefulSession.addEventListener( new DebugAgendaEventListener() );
		statefulSession.addEventListener( new DebugWorkingMemoryEventListener() );
		Client client = new Client();
		client.setDesengage(true);
		client.setTypeOffre("N");
		statefulSession.insert(client);
		statefulSession.fireAllRules();
		assertEquals("insert into Client (marqueur) values ('1');", client.getRequete());
	
	
	}

}
