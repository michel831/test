package fr.bd.demo.produit.drools.tests;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.impl.ClassPathResource;
import org.drools.runtime.StatefulKnowledgeSession;
import org.drools.runtime.rule.impl.AgendaImpl;
import org.junit.Before;
import org.junit.Test;

import fr.bd.demo.metier.object.auto.GarantieOfferte;
import fr.bd.demo.metier.object.auto.OptionProduit;

public class FormulesTest {

	private StatefulKnowledgeSession ksession;
	private List<GarantieOfferte> garanties;
	

	@Before
	public void setUp() throws Exception {
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder();
		 kbuilder.add(new ClassPathResource("/Formules/Formules.dsl",
				getClass()), ResourceType.DSL);
		 kbuilder.add(new ClassPathResource("/Formules/Formules.dslr",
		 getClass()), ResourceType.DSLR);
		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}
		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());

		ksession = kbase.newStatefulKnowledgeSession();
		
		garanties = new ArrayList<GarantieOfferte>();
		GarantieOfferte garantie1 = new GarantieOfferte();
		garantie1.setKey("ASS");
		garanties.add(garantie1);
		
		GarantieOfferte garantie2 = new GarantieOfferte();
		garantie2.setKey("RC");
		garanties.add(garantie2);
		
		GarantieOfferte garantie3 = new GarantieOfferte();
		garantie3.setKey("DPRSA");
		garanties.add(garantie3);
		
		GarantieOfferte garantie4 = new GarantieOfferte();
		garantie4.setKey("IV");
		garanties.add(garantie4);
		
		GarantieOfferte garantie5 = new GarantieOfferte();
		garantie5.setKey("CANAT");
		garanties.add(garantie5);
		
		GarantieOfferte garantie6 = new GarantieOfferte();
		garantie6.setKey("SDC450");
		garanties.add(garantie6);
		
		GarantieOfferte garantie7 = new GarantieOfferte();
		garantie7.setKey("SDC800");
		garanties.add(garantie7);
		
		GarantieOfferte garantie8 = new GarantieOfferte();
		garantie8.setKey("DOMMAGETTACCID");
		garanties.add(garantie8);
		
		GarantieOfferte garantie9 = new GarantieOfferte();
		garantie9.setKey("BG");
		garanties.add(garantie9);
		
		GarantieOfferte garantie10 = new GarantieOfferte();
		garantie10.setKey("REMPLACEMENTVEHIC");
		garanties.add(garantie10);
	}

	@Test
	public void testFormule1() {
		List<OptionProduit> formules = new ArrayList<OptionProduit>();
		
		OptionProduit formule = new OptionProduit();
		formule.setKey("Formule 1");
		formules.add(formule);
		ksession.setGlobal("garantiesPossibles", garanties);
		ksession.setGlobal("formulesPossibles", formules);
		((AgendaImpl)ksession.getAgenda()).activateRuleFlowGroup("formule");
		ksession.fireAllRules();
		assertEquals(3, formule.getIsComposedOf().size());
	}
	
	@Test
	public void testFormule2() {
		List<OptionProduit> formules = new ArrayList<OptionProduit>();
		
		OptionProduit formule = new OptionProduit();
		formule.setKey("Formule 2");
		formules.add(formule);
		ksession.setGlobal("garantiesPossibles", garanties);
		ksession.setGlobal("formulesPossibles", formules);
		((AgendaImpl)ksession.getAgenda()).activateRuleFlowGroup("formule");
		ksession.fireAllRules();
		assertEquals(6, formule.getIsComposedOf().size());
	}
	
	@Test
	public void testFormule3() {
		List<OptionProduit> formules = new ArrayList<OptionProduit>();
		
		OptionProduit formule = new OptionProduit();
		formule.setKey("Formule 3");
		formules.add(formule);
		ksession.setGlobal("garantiesPossibles", garanties);
		ksession.setGlobal("formulesPossibles", formules);
		((AgendaImpl)ksession.getAgenda()).activateRuleFlowGroup("formule");
		ksession.fireAllRules();
		assertEquals(10, formule.getIsComposedOf().size());
	}


}
