package fr.bd.demo.produit.drools.tests;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.drools.KnowledgeBase;
import org.drools.command.Command;
import org.drools.command.CommandFactory;
import org.drools.event.rule.DebugAgendaEventListener;
import org.drools.event.rule.DebugWorkingMemoryEventListener;
import org.drools.runtime.ExecutionResults;
import org.drools.runtime.StatefulKnowledgeSession;
import org.drools.runtime.StatelessKnowledgeSession;
import org.drools.runtime.process.WorkflowProcessInstance;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import fr.bd.demo.metier.object.DefinitionProduit;
import fr.bd.demo.metier.object.auto.GarantieOfferte;
import fr.bd.demo.metier.object.auto.OptionProduit;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration( { "classpath:spring-produit-config.xml" })
public class ProduitTest {
	
	@Autowired
	private KnowledgeBase kbase;
	
	@SuppressWarnings("unchecked")
	@Test
	public void testStatefulProduit() {
		StatefulKnowledgeSession statefulSession = kbase.newStatefulKnowledgeSession();
		statefulSession.addEventListener( new DebugAgendaEventListener() );
		statefulSession.addEventListener( new DebugWorkingMemoryEventListener() );
		statefulSession.setGlobal("garantiesPossibles", new ArrayList<GarantieOfferte>());
		statefulSession.setGlobal("formulesPossibles", new ArrayList<OptionProduit>());
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("nom", "EAuto");
		params.put("produit", null);
		WorkflowProcessInstance process = (WorkflowProcessInstance) statefulSession.startProcess("fr.bd.demo.drools.produit",params);
		statefulSession.fireAllRules();
		List<GarantieOfferte> garanties = (List<GarantieOfferte>) statefulSession.getGlobal("garantiesPossibles");
		List<OptionProduit> formules = (List<OptionProduit>) statefulSession.getGlobal("formulesPossibles");
		assertEquals(10, garanties.size());
		assertEquals(3, formules.size());
		assertEquals("EAuto", ((DefinitionProduit)process.getVariable("produit")).getNom());
		assertEquals(13, ((DefinitionProduit)process.getVariable("produit")).getIsComposedOf().size());
		statefulSession.dispose();
	}
	
	
	@SuppressWarnings("unchecked")
	@Test
	public void testStatelessProduit() {
		StatelessKnowledgeSession statelessSession = kbase.newStatelessKnowledgeSession();
		statelessSession.addEventListener( new DebugAgendaEventListener() );
		statelessSession.addEventListener( new DebugWorkingMemoryEventListener() );
		List<Command<?>> list = new ArrayList<Command<?>>();
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("nom", "EAuto");
		params.put("produit", null);
		list.add(CommandFactory.newSetGlobal("garantiesPossibles", new ArrayList<GarantieOfferte>(), true));
		list.add(CommandFactory.newSetGlobal("formulesPossibles", new ArrayList<OptionProduit>(), true));
		list.add(new StartProcessWithOutIdentifierCommand("fr.bd.demo.drools.produit", params, "process"));
		ExecutionResults results = statelessSession.execute(CommandFactory.newBatchExecution(list));
		assertEquals(10, ((List<GarantieOfferte>)results.getValue("garantiesPossibles")).size());
		assertEquals(3, ((List<OptionProduit>)results.getValue("formulesPossibles")).size());
		DefinitionProduit produit = (DefinitionProduit) (((WorkflowProcessInstance) results.getValue("process"))).getVariable("produit");
		assertEquals("EAuto", produit.getNom());
		assertEquals(13, produit.getIsComposedOf().size());
	}

}
