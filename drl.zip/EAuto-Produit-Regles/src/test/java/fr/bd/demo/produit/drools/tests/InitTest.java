package fr.bd.demo.produit.drools.tests;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.impl.ClassPathResource;
import org.drools.runtime.StatefulKnowledgeSession;
import org.drools.runtime.rule.impl.AgendaImpl;
import org.junit.Before;
import org.junit.Test;

import fr.bd.demo.metier.object.auto.GarantieOfferte;
import fr.bd.demo.metier.object.auto.OptionProduit;

public class InitTest {

	private StatefulKnowledgeSession ksession;

	@Before
	public void setUp() throws Exception {
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory
				.newKnowledgeBuilder();
		kbuilder.add(new ClassPathResource("/Initialisation/Init.dsl",
				getClass()), ResourceType.DSL);
		kbuilder.add(new ClassPathResource("/Initialisation/Init.dslr",
				getClass()), ResourceType.DSLR);
		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if (errors.size() > 0) {
			for (KnowledgeBuilderError error : errors) {
				System.err.println(error);
			}
			throw new IllegalArgumentException("Could not parse knowledge.");
		}
		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());

		ksession = kbase.newStatefulKnowledgeSession();
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testInit() {
		ksession.setGlobal("garantiesPossibles", new ArrayList<GarantieOfferte>());
		ksession.setGlobal("formulesPossibles", new ArrayList<OptionProduit>());
		((AgendaImpl)ksession.getAgenda()).activateRuleFlowGroup("init");
		ksession.fireAllRules();
		List<GarantieOfferte> garanties = (List<GarantieOfferte>) ksession.getGlobal("garantiesPossibles");
		List<OptionProduit> formules = (List<OptionProduit>) ksession.getGlobal("formulesPossibles");
		assertEquals(10, garanties.size());
		assertEquals(3, formules.size());
	}

}
