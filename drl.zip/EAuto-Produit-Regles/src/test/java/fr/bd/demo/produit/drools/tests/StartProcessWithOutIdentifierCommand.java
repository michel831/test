package fr.bd.demo.produit.drools.tests;

import java.util.Map;

import org.drools.command.Context;
import org.drools.command.impl.KnowledgeCommandContext;
import org.drools.command.runtime.process.StartProcessCommand;
import org.drools.impl.StatefulKnowledgeSessionImpl;
import org.drools.runtime.StatefulKnowledgeSession;
import org.drools.runtime.process.ProcessInstance;
import org.drools.runtime.process.WorkflowProcessInstance;

public class StartProcessWithOutIdentifierCommand extends StartProcessCommand {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public StartProcessWithOutIdentifierCommand(String process) {
		
	}
	
	public StartProcessWithOutIdentifierCommand(String processId, String outIdentifier) {
        super(processId, outIdentifier);
    }

    public StartProcessWithOutIdentifierCommand(String processId, Map<String, Object> parameters, String outIdentifier) {
    	super(processId, parameters, outIdentifier);
    }
	
	@Override
	public ProcessInstance execute(Context context) {
		StatefulKnowledgeSession ksession = ((KnowledgeCommandContext) context).getStatefulKnowledgesession();

        if (getData() != null) {
            for (Object o: getData()) {
                ksession.insert(o);
            }
        }
        WorkflowProcessInstance processInstance = (WorkflowProcessInstance) ksession.startProcess(getProcessId(), getParameters());
        if ( getOutIdentifier() != null ) {
        	StatefulKnowledgeSessionImpl statefulKnowledgeSession = (StatefulKnowledgeSessionImpl) ((KnowledgeCommandContext) context).getStatefulKnowledgesession();
            statefulKnowledgeSession.session.getExecutionResult().getResults().put(getOutIdentifier(), processInstance);
        }
        return processInstance;
	}

}
