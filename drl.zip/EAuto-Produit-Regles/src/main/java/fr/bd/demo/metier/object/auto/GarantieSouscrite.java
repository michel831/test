//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.11 � 09:51:37 AM CEST 
//


package fr.bd.demo.metier.object.auto;

import java.math.BigInteger;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import fr.bd.demo.metier.object.ComposantContrat;
import org.w3._2001.xmlschema.Adapter1;


/**
 * <p>Classe Java pour GarantieSouscrite complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="GarantieSouscrite">
 *   &lt;complexContent>
 *     &lt;extension base="{http://object.metier.demo.bd.fr/}ComposantContrat">
 *       &lt;sequence>
 *         &lt;element name="montantExpose" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="dureeEligibilte" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *         &lt;element name="dureeCarence" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *         &lt;element name="dureeDeclarationPostContrat" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *         &lt;element name="dateDebutRetroactive" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="prioriteGarantie" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="codeGarantie" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GarantieSouscrite", propOrder = {
    "montantExpose",
    "dureeEligibilte",
    "dureeCarence",
    "dureeDeclarationPostContrat",
    "dateDebutRetroactive",
    "prioriteGarantie",
    "codeGarantie"
})
public class GarantieSouscrite
    extends ComposantContrat
{

    protected double montantExpose;
    @XmlElement(required = true)
    protected BigInteger dureeEligibilte;
    @XmlElement(required = true)
    protected BigInteger dureeCarence;
    @XmlElement(required = true)
    protected BigInteger dureeDeclarationPostContrat;
    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "date")
    protected Date dateDebutRetroactive;
    protected int prioriteGarantie;
    @XmlElement(required = true)
    protected String codeGarantie;

    /**
     * Obtient la valeur de la propri�t� montantExpose.
     * 
     */
    public double getMontantExpose() {
        return montantExpose;
    }

    /**
     * D�finit la valeur de la propri�t� montantExpose.
     * 
     */
    public void setMontantExpose(double value) {
        this.montantExpose = value;
    }

    /**
     * Obtient la valeur de la propri�t� dureeEligibilte.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDureeEligibilte() {
        return dureeEligibilte;
    }

    /**
     * D�finit la valeur de la propri�t� dureeEligibilte.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDureeEligibilte(BigInteger value) {
        this.dureeEligibilte = value;
    }

    /**
     * Obtient la valeur de la propri�t� dureeCarence.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDureeCarence() {
        return dureeCarence;
    }

    /**
     * D�finit la valeur de la propri�t� dureeCarence.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDureeCarence(BigInteger value) {
        this.dureeCarence = value;
    }

    /**
     * Obtient la valeur de la propri�t� dureeDeclarationPostContrat.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDureeDeclarationPostContrat() {
        return dureeDeclarationPostContrat;
    }

    /**
     * D�finit la valeur de la propri�t� dureeDeclarationPostContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDureeDeclarationPostContrat(BigInteger value) {
        this.dureeDeclarationPostContrat = value;
    }

    /**
     * Obtient la valeur de la propri�t� dateDebutRetroactive.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDateDebutRetroactive() {
        return dateDebutRetroactive;
    }

    /**
     * D�finit la valeur de la propri�t� dateDebutRetroactive.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateDebutRetroactive(Date value) {
        this.dateDebutRetroactive = value;
    }

    /**
     * Obtient la valeur de la propri�t� prioriteGarantie.
     * 
     */
    public int getPrioriteGarantie() {
        return prioriteGarantie;
    }

    /**
     * D�finit la valeur de la propri�t� prioriteGarantie.
     * 
     */
    public void setPrioriteGarantie(int value) {
        this.prioriteGarantie = value;
    }

    /**
     * Obtient la valeur de la propri�t� codeGarantie.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeGarantie() {
        return codeGarantie;
    }

    /**
     * D�finit la valeur de la propri�t� codeGarantie.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeGarantie(String value) {
        this.codeGarantie = value;
    }

}
