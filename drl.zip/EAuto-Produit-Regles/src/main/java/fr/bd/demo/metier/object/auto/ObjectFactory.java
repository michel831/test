//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.10 � 04:55:30 PM CEST 
//


package fr.bd.demo.metier.object.auto;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the fr.bd.demo.metier.object.auto package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: fr.bd.demo.metier.object.auto
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link OptionPaiement }
     * 
     */
    public OptionPaiement createOptionPaiement() {
        return new OptionPaiement();
    }

    /**
     * Create an instance of {@link Voiture }
     * 
     */
    public Voiture createVoiture() {
        return new Voiture();
    }

    /**
     * Create an instance of {@link Vehicule }
     * 
     */
    public Vehicule createVehicule() {
        return new Vehicule();
    }

    /**
     * Create an instance of {@link ReponseDemande }
     * 
     */
    public ReponseDemande createReponseDemande() {
        return new ReponseDemande();
    }

    /**
     * Create an instance of {@link DefautAssurance }
     * 
     */
    public DefautAssurance createDefautAssurance() {
        return new DefautAssurance();
    }

    /**
     * Create an instance of {@link GarantieSouscrite }
     * 
     */
    public GarantieSouscrite createGarantieSouscrite() {
        return new GarantieSouscrite();
    }

    /**
     * Create an instance of {@link OptionProduit }
     * 
     */
    public OptionProduit createOptionProduit() {
        return new OptionProduit();
    }

    /**
     * Create an instance of {@link GarantieOfferte }
     * 
     */
    public GarantieOfferte createGarantieOfferte() {
        return new GarantieOfferte();
    }

    /**
     * Create an instance of {@link DetailsPersonnePhysique }
     * 
     */
    public DetailsPersonnePhysique createDetailsPersonnePhysique() {
        return new DetailsPersonnePhysique();
    }

    /**
     * Create an instance of {@link Occupation }
     * 
     */
    public Occupation createOccupation() {
        return new Occupation();
    }

    /**
     * Create an instance of {@link ContratServiceFinancier }
     * 
     */
    public ContratServiceFinancier createContratServiceFinancier() {
        return new ContratServiceFinancier();
    }

    /**
     * Create an instance of {@link SpecificationVehicule }
     * 
     */
    public SpecificationVehicule createSpecificationVehicule() {
        return new SpecificationVehicule();
    }

    /**
     * Create an instance of {@link SpecificationVehiculeTerrestre }
     * 
     */
    public SpecificationVehiculeTerrestre createSpecificationVehiculeTerrestre() {
        return new SpecificationVehiculeTerrestre();
    }

    /**
     * Create an instance of {@link SpecificiteMoteur }
     * 
     */
    public SpecificiteMoteur createSpecificiteMoteur() {
        return new SpecificiteMoteur();
    }

    /**
     * Create an instance of {@link ServiceOffert }
     * 
     */
    public ServiceOffert createServiceOffert() {
        return new ServiceOffert();
    }

    /**
     * Create an instance of {@link ExperienceConduite }
     * 
     */
    public ExperienceConduite createExperienceConduite() {
        return new ExperienceConduite();
    }

    /**
     * Create an instance of {@link VehiculeTerrestre }
     * 
     */
    public VehiculeTerrestre createVehiculeTerrestre() {
        return new VehiculeTerrestre();
    }

    /**
     * Create an instance of {@link Risque }
     * 
     */
    public Risque createRisque() {
        return new Risque();
    }

    /**
     * Create an instance of {@link ContratAssurance }
     * 
     */
    public ContratAssurance createContratAssurance() {
        return new ContratAssurance();
    }

    /**
     * Create an instance of {@link OptionSouscrite }
     * 
     */
    public OptionSouscrite createOptionSouscrite() {
        return new OptionSouscrite();
    }

    /**
     * Create an instance of {@link InfractionConduite }
     * 
     */
    public InfractionConduite createInfractionConduite() {
        return new InfractionConduite();
    }

    /**
     * Create an instance of {@link ConduiteEtatIvresse }
     * 
     */
    public ConduiteEtatIvresse createConduiteEtatIvresse() {
        return new ConduiteEtatIvresse();
    }

    /**
     * Create an instance of {@link RetraitPermis }
     * 
     */
    public RetraitPermis createRetraitPermis() {
        return new RetraitPermis();
    }

    /**
     * Create an instance of {@link PersonnePhysique }
     * 
     */
    public PersonnePhysique createPersonnePhysique() {
        return new PersonnePhysique();
    }

}
