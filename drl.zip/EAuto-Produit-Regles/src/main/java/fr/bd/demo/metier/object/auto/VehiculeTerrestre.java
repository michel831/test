//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.11 � 09:51:37 AM CEST 
//


package fr.bd.demo.metier.object.auto;

import java.math.BigInteger;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import org.w3._2001.xmlschema.Adapter1;


/**
 * <p>Classe Java pour VehiculeTerrestre complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="VehiculeTerrestre">
 *   &lt;complexContent>
 *     &lt;extension base="{http://auto.object.metier.demo.bd.fr/}Vehicule">
 *       &lt;sequence>
 *         &lt;element name="date1erMiseEnCirculation" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="poidsTotalRemorque" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="utilisation" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="utilisationSpecifiqueVehicule" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="dureeUtilisationVehicule" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *         &lt;element name="nbConducteurs" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="acheteNeuf" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="valeurAccessoires" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="typeDeLeasing" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="kilometrageAnnuelMoyen" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="capaciteDeDommagesVehicule" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="specificationVehiculeTerrestre" type="{http://auto.object.metier.demo.bd.fr/}SpecificationVehiculeTerrestre" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "VehiculeTerrestre", propOrder = {
    "date1ErMiseEnCirculation",
    "poidsTotalRemorque",
    "utilisation",
    "utilisationSpecifiqueVehicule",
    "dureeUtilisationVehicule",
    "nbConducteurs",
    "acheteNeuf",
    "valeurAccessoires",
    "typeDeLeasing",
    "kilometrageAnnuelMoyen",
    "capaciteDeDommagesVehicule",
    "specificationVehiculeTerrestre"
})
@XmlSeeAlso({
    Voiture.class
})
public class VehiculeTerrestre
    extends Vehicule
{

    @XmlElement(name = "date1erMiseEnCirculation", required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "date")
    protected Date date1ErMiseEnCirculation;
    protected double poidsTotalRemorque;
    @XmlElement(required = true)
    protected String utilisation;
    @XmlElement(required = true)
    protected String utilisationSpecifiqueVehicule;
    @XmlElement(required = true)
    protected BigInteger dureeUtilisationVehicule;
    protected int nbConducteurs;
    protected boolean acheteNeuf;
    protected double valeurAccessoires;
    @XmlElement(required = true)
    protected String typeDeLeasing;
    protected double kilometrageAnnuelMoyen;
    @XmlElement(required = true)
    protected String capaciteDeDommagesVehicule;
    protected SpecificationVehiculeTerrestre specificationVehiculeTerrestre;

    /**
     * Obtient la valeur de la propri�t� date1ErMiseEnCirculation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDate1ErMiseEnCirculation() {
        return date1ErMiseEnCirculation;
    }

    /**
     * D�finit la valeur de la propri�t� date1ErMiseEnCirculation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDate1ErMiseEnCirculation(Date value) {
        this.date1ErMiseEnCirculation = value;
    }

    /**
     * Obtient la valeur de la propri�t� poidsTotalRemorque.
     * 
     */
    public double getPoidsTotalRemorque() {
        return poidsTotalRemorque;
    }

    /**
     * D�finit la valeur de la propri�t� poidsTotalRemorque.
     * 
     */
    public void setPoidsTotalRemorque(double value) {
        this.poidsTotalRemorque = value;
    }

    /**
     * Obtient la valeur de la propri�t� utilisation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilisation() {
        return utilisation;
    }

    /**
     * D�finit la valeur de la propri�t� utilisation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilisation(String value) {
        this.utilisation = value;
    }

    /**
     * Obtient la valeur de la propri�t� utilisationSpecifiqueVehicule.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUtilisationSpecifiqueVehicule() {
        return utilisationSpecifiqueVehicule;
    }

    /**
     * D�finit la valeur de la propri�t� utilisationSpecifiqueVehicule.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUtilisationSpecifiqueVehicule(String value) {
        this.utilisationSpecifiqueVehicule = value;
    }

    /**
     * Obtient la valeur de la propri�t� dureeUtilisationVehicule.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDureeUtilisationVehicule() {
        return dureeUtilisationVehicule;
    }

    /**
     * D�finit la valeur de la propri�t� dureeUtilisationVehicule.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDureeUtilisationVehicule(BigInteger value) {
        this.dureeUtilisationVehicule = value;
    }

    /**
     * Obtient la valeur de la propri�t� nbConducteurs.
     * 
     */
    public int getNbConducteurs() {
        return nbConducteurs;
    }

    /**
     * D�finit la valeur de la propri�t� nbConducteurs.
     * 
     */
    public void setNbConducteurs(int value) {
        this.nbConducteurs = value;
    }

    /**
     * Obtient la valeur de la propri�t� acheteNeuf.
     * 
     */
    public boolean isAcheteNeuf() {
        return acheteNeuf;
    }

    /**
     * D�finit la valeur de la propri�t� acheteNeuf.
     * 
     */
    public void setAcheteNeuf(boolean value) {
        this.acheteNeuf = value;
    }

    /**
     * Obtient la valeur de la propri�t� valeurAccessoires.
     * 
     */
    public double getValeurAccessoires() {
        return valeurAccessoires;
    }

    /**
     * D�finit la valeur de la propri�t� valeurAccessoires.
     * 
     */
    public void setValeurAccessoires(double value) {
        this.valeurAccessoires = value;
    }

    /**
     * Obtient la valeur de la propri�t� typeDeLeasing.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeDeLeasing() {
        return typeDeLeasing;
    }

    /**
     * D�finit la valeur de la propri�t� typeDeLeasing.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeDeLeasing(String value) {
        this.typeDeLeasing = value;
    }

    /**
     * Obtient la valeur de la propri�t� kilometrageAnnuelMoyen.
     * 
     */
    public double getKilometrageAnnuelMoyen() {
        return kilometrageAnnuelMoyen;
    }

    /**
     * D�finit la valeur de la propri�t� kilometrageAnnuelMoyen.
     * 
     */
    public void setKilometrageAnnuelMoyen(double value) {
        this.kilometrageAnnuelMoyen = value;
    }

    /**
     * Obtient la valeur de la propri�t� capaciteDeDommagesVehicule.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCapaciteDeDommagesVehicule() {
        return capaciteDeDommagesVehicule;
    }

    /**
     * D�finit la valeur de la propri�t� capaciteDeDommagesVehicule.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCapaciteDeDommagesVehicule(String value) {
        this.capaciteDeDommagesVehicule = value;
    }

    /**
     * Obtient la valeur de la propri�t� specificationVehiculeTerrestre.
     * 
     * @return
     *     possible object is
     *     {@link SpecificationVehiculeTerrestre }
     *     
     */
    public SpecificationVehiculeTerrestre getSpecificationVehiculeTerrestre() {
        return specificationVehiculeTerrestre;
    }

    /**
     * D�finit la valeur de la propri�t� specificationVehiculeTerrestre.
     * 
     * @param value
     *     allowed object is
     *     {@link SpecificationVehiculeTerrestre }
     *     
     */
    public void setSpecificationVehiculeTerrestre(SpecificationVehiculeTerrestre value) {
        this.specificationVehiculeTerrestre = value;
    }

}
