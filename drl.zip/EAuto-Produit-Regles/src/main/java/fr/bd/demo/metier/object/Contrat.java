//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.28 � 10:43:07 AM CEST 
//


package fr.bd.demo.metier.object;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import fr.bd.demo.metier.object.auto.ContratServiceFinancier;
import org.w3._2001.xmlschema.Adapter1;


/**
 * <p>Classe Java pour Contrat complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="Contrat">
 *   &lt;complexContent>
 *     &lt;extension base="{http://object.metier.demo.bd.fr/}ObjetReference">
 *       &lt;sequence>
 *         &lt;element name="typeContrat" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="dateSouscription" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="dateEffet" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="dateFinContrat" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="dateRevision" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="version" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="statut" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codeRaisonStatut" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="devise" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="regimeFiscal" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="prime" type="{http://object.metier.demo.bd.fr/}Prime" minOccurs="0"/>
 *         &lt;element name="souscripteur" type="{http://object.metier.demo.bd.fr/}Personne"/>
 *         &lt;element name="objetPhysique" type="{http://object.metier.demo.bd.fr/}ObjetPhysique"/>
 *         &lt;element name="composantContrat" type="{http://object.metier.demo.bd.fr/}ComposantContrat" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Contrat", propOrder = {
    "typeContrat",
    "dateSouscription",
    "dateEffet",
    "dateFinContrat",
    "dateRevision",
    "version",
    "statut",
    "codeRaisonStatut",
    "devise",
    "regimeFiscal",
    "prime",
    "souscripteur",
    "objetPhysique",
    "composantContrat"
})
@XmlSeeAlso({
    ContratServiceFinancier.class
})
public class Contrat
    extends ObjetReference
{

    @XmlElement(required = true)
    protected String typeContrat;
    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "date")
    protected Date dateSouscription;
    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "date")
    protected Date dateEffet;
    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "date")
    protected Date dateFinContrat;
    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "date")
    protected Date dateRevision;
    @XmlElement(required = true)
    protected String version;
    @XmlElement(required = true)
    protected String statut;
    @XmlElement(required = true)
    protected String codeRaisonStatut;
    @XmlElement(required = true)
    protected String devise;
    @XmlElement(required = true)
    protected String regimeFiscal;
    protected Prime prime;
    @XmlElement(required = true)
    protected Personne souscripteur;
    @XmlElement(required = true)
    protected ObjetPhysique objetPhysique;
    @XmlElement(required = true)
    protected List<ComposantContrat> composantContrat;

    /**
     * Obtient la valeur de la propri�t� typeContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeContrat() {
        return typeContrat;
    }

    /**
     * D�finit la valeur de la propri�t� typeContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeContrat(String value) {
        this.typeContrat = value;
    }

    /**
     * Obtient la valeur de la propri�t� dateSouscription.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDateSouscription() {
        return dateSouscription;
    }

    /**
     * D�finit la valeur de la propri�t� dateSouscription.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateSouscription(Date value) {
        this.dateSouscription = value;
    }

    /**
     * Obtient la valeur de la propri�t� dateEffet.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDateEffet() {
        return dateEffet;
    }

    /**
     * D�finit la valeur de la propri�t� dateEffet.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateEffet(Date value) {
        this.dateEffet = value;
    }

    /**
     * Obtient la valeur de la propri�t� dateFinContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDateFinContrat() {
        return dateFinContrat;
    }

    /**
     * D�finit la valeur de la propri�t� dateFinContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateFinContrat(Date value) {
        this.dateFinContrat = value;
    }

    /**
     * Obtient la valeur de la propri�t� dateRevision.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDateRevision() {
        return dateRevision;
    }

    /**
     * D�finit la valeur de la propri�t� dateRevision.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateRevision(Date value) {
        this.dateRevision = value;
    }

    /**
     * Obtient la valeur de la propri�t� version.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVersion() {
        return version;
    }

    /**
     * D�finit la valeur de la propri�t� version.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVersion(String value) {
        this.version = value;
    }

    /**
     * Obtient la valeur de la propri�t� statut.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatut() {
        return statut;
    }

    /**
     * D�finit la valeur de la propri�t� statut.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatut(String value) {
        this.statut = value;
    }

    /**
     * Obtient la valeur de la propri�t� codeRaisonStatut.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeRaisonStatut() {
        return codeRaisonStatut;
    }

    /**
     * D�finit la valeur de la propri�t� codeRaisonStatut.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeRaisonStatut(String value) {
        this.codeRaisonStatut = value;
    }

    /**
     * Obtient la valeur de la propri�t� devise.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDevise() {
        return devise;
    }

    /**
     * D�finit la valeur de la propri�t� devise.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDevise(String value) {
        this.devise = value;
    }

    /**
     * Obtient la valeur de la propri�t� regimeFiscal.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegimeFiscal() {
        return regimeFiscal;
    }

    /**
     * D�finit la valeur de la propri�t� regimeFiscal.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegimeFiscal(String value) {
        this.regimeFiscal = value;
    }

    /**
     * Obtient la valeur de la propri�t� prime.
     * 
     * @return
     *     possible object is
     *     {@link Prime }
     *     
     */
    public Prime getPrime() {
        return prime;
    }

    /**
     * D�finit la valeur de la propri�t� prime.
     * 
     * @param value
     *     allowed object is
     *     {@link Prime }
     *     
     */
    public void setPrime(Prime value) {
        this.prime = value;
    }

    /**
     * Obtient la valeur de la propri�t� souscripteur.
     * 
     * @return
     *     possible object is
     *     {@link Personne }
     *     
     */
    public Personne getSouscripteur() {
        return souscripteur;
    }

    /**
     * D�finit la valeur de la propri�t� souscripteur.
     * 
     * @param value
     *     allowed object is
     *     {@link Personne }
     *     
     */
    public void setSouscripteur(Personne value) {
        this.souscripteur = value;
    }

    /**
     * Obtient la valeur de la propri�t� objetPhysique.
     * 
     * @return
     *     possible object is
     *     {@link ObjetPhysique }
     *     
     */
    public ObjetPhysique getObjetPhysique() {
        return objetPhysique;
    }

    /**
     * D�finit la valeur de la propri�t� objetPhysique.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjetPhysique }
     *     
     */
    public void setObjetPhysique(ObjetPhysique value) {
        this.objetPhysique = value;
    }

    /**
     * Gets the value of the composantContrat property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the composantContrat property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getComposantContrat().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ComposantContrat }
     * 
     * 
     */
    public List<ComposantContrat> getComposantContrat() {
        if (composantContrat == null) {
            composantContrat = new ArrayList<ComposantContrat>();
        }
        return this.composantContrat;
    }

}
