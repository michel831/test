//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.10 � 04:55:30 PM CEST 
//


package fr.bd.demo.metier.object;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the fr.bd.demo.metier.object package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: fr.bd.demo.metier.object
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Prime }
     * 
     */
    public Prime createPrime() {
        return new Prime();
    }

    /**
     * Create an instance of {@link CaracteristiqueProduit }
     * 
     */
    public CaracteristiqueProduit createCaracteristiqueProduit() {
        return new CaracteristiqueProduit();
    }

    /**
     * Create an instance of {@link ObjetPhysique }
     * 
     */
    public ObjetPhysique createObjetPhysique() {
        return new ObjetPhysique();
    }

    /**
     * Create an instance of {@link ComposantContrat }
     * 
     */
    public ComposantContrat createComposantContrat() {
        return new ComposantContrat();
    }

    /**
     * Create an instance of {@link Contrat }
     * 
     */
    public Contrat createContrat() {
        return new Contrat();
    }

    /**
     * Create an instance of {@link Personne }
     * 
     */
    public Personne createPersonne() {
        return new Personne();
    }

    /**
     * Create an instance of {@link Clause }
     * 
     */
    public Clause createClause() {
        return new Clause();
    }

    /**
     * Create an instance of {@link ValeurAttribut }
     * 
     */
    public ValeurAttribut createValeurAttribut() {
        return new ValeurAttribut();
    }

    /**
     * Create an instance of {@link ParametreProduit }
     * 
     */
    public ParametreProduit createParametreProduit() {
        return new ParametreProduit();
    }

    /**
     * Create an instance of {@link ComposantProduit }
     * 
     */
    public ComposantProduit createComposantProduit() {
        return new ComposantProduit();
    }

    /**
     * Create an instance of {@link DefinitionProduit }
     * 
     */
    public DefinitionProduit createDefinitionProduit() {
        return new DefinitionProduit();
    }

}
