//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.10 � 04:55:30 PM CEST 
//


package fr.bd.demo.metier.object.auto;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import fr.bd.demo.metier.object.ObjetReference;
import org.w3._2001.xmlschema.Adapter1;


/**
 * <p>Classe Java pour InfractionConduite complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="InfractionConduite">
 *   &lt;complexContent>
 *     &lt;extension base="{http://object.metier.demo.bd.fr/}ObjetReference">
 *       &lt;sequence>
 *         &lt;element name="typeIncidentCriminel" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="incidentDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="incidentDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="incidentStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="incidentStatusDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InfractionConduite", propOrder = {
    "typeIncidentCriminel",
    "incidentDate",
    "incidentDescription",
    "incidentStatus",
    "incidentStatusDate"
})
@XmlSeeAlso({
    DefautAssurance.class,
    ConduiteEtatIvresse.class,
    RetraitPermis.class
})
public class InfractionConduite
    extends ObjetReference
{

    @XmlElement(required = true)
    protected String typeIncidentCriminel;
    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "date")
    protected Date incidentDate;
    @XmlElement(required = true)
    protected String incidentDescription;
    @XmlElement(required = true)
    protected String incidentStatus;
    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "date")
    protected Date incidentStatusDate;

    /**
     * Obtient la valeur de la propri�t� typeIncidentCriminel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeIncidentCriminel() {
        return typeIncidentCriminel;
    }

    /**
     * D�finit la valeur de la propri�t� typeIncidentCriminel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeIncidentCriminel(String value) {
        this.typeIncidentCriminel = value;
    }

    /**
     * Obtient la valeur de la propri�t� incidentDate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getIncidentDate() {
        return incidentDate;
    }

    /**
     * D�finit la valeur de la propri�t� incidentDate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIncidentDate(Date value) {
        this.incidentDate = value;
    }

    /**
     * Obtient la valeur de la propri�t� incidentDescription.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIncidentDescription() {
        return incidentDescription;
    }

    /**
     * D�finit la valeur de la propri�t� incidentDescription.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIncidentDescription(String value) {
        this.incidentDescription = value;
    }

    /**
     * Obtient la valeur de la propri�t� incidentStatus.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIncidentStatus() {
        return incidentStatus;
    }

    /**
     * D�finit la valeur de la propri�t� incidentStatus.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIncidentStatus(String value) {
        this.incidentStatus = value;
    }

    /**
     * Obtient la valeur de la propri�t� incidentStatusDate.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getIncidentStatusDate() {
        return incidentStatusDate;
    }

    /**
     * D�finit la valeur de la propri�t� incidentStatusDate.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIncidentStatusDate(Date value) {
        this.incidentStatusDate = value;
    }

}
