//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.28 � 10:43:07 AM CEST 
//


package fr.bd.demo.metier.object.auto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import fr.bd.demo.metier.object.ObjetPhysique;


/**
 * <p>Classe Java pour Vehicule complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="Vehicule">
 *   &lt;complexContent>
 *     &lt;extension base="{http://object.metier.demo.bd.fr/}ObjetPhysique">
 *       &lt;sequence>
 *         &lt;element name="presenceAntivol" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="modele" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="marque" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="specificationVehicule" type="{http://auto.object.metier.demo.bd.fr/}SpecificationVehicule" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Vehicule", propOrder = {
    "presenceAntivol",
    "modele",
    "marque",
    "specificationVehicule"
})
@XmlSeeAlso({
    VehiculeTerrestre.class
})
public class Vehicule
    extends ObjetPhysique
{

    protected boolean presenceAntivol;
    @XmlElement(required = true)
    protected String modele;
    @XmlElement(required = true)
    protected String marque;
    @XmlElement(required = true)
    protected List<SpecificationVehicule> specificationVehicule;

    /**
     * Obtient la valeur de la propri�t� presenceAntivol.
     * 
     */
    public boolean isPresenceAntivol() {
        return presenceAntivol;
    }

    /**
     * D�finit la valeur de la propri�t� presenceAntivol.
     * 
     */
    public void setPresenceAntivol(boolean value) {
        this.presenceAntivol = value;
    }

    /**
     * Obtient la valeur de la propri�t� modele.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModele() {
        return modele;
    }

    /**
     * D�finit la valeur de la propri�t� modele.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModele(String value) {
        this.modele = value;
    }

    /**
     * Obtient la valeur de la propri�t� marque.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMarque() {
        return marque;
    }

    /**
     * D�finit la valeur de la propri�t� marque.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMarque(String value) {
        this.marque = value;
    }

    /**
     * Gets the value of the specificationVehicule property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the specificationVehicule property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSpecificationVehicule().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SpecificationVehicule }
     * 
     * 
     */
    public List<SpecificationVehicule> getSpecificationVehicule() {
        if (specificationVehicule == null) {
            specificationVehicule = new ArrayList<SpecificationVehicule>();
        }
        return this.specificationVehicule;
    }

}
