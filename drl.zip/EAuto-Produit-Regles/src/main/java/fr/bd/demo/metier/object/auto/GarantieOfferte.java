//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.10 � 04:55:30 PM CEST 
//


package fr.bd.demo.metier.object.auto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import fr.bd.demo.metier.object.ComposantProduit;


/**
 * <p>Classe Java pour GarantieOfferte complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="GarantieOfferte">
 *   &lt;complexContent>
 *     &lt;extension base="{http://object.metier.demo.bd.fr/}ComposantProduit">
 *       &lt;sequence>
 *         &lt;element name="nbOccurencesRisquesCouverts" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="modeCalculDatePourAge" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codeUT" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="risque" type="{http://auto.object.metier.demo.bd.fr/}Risque" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GarantieOfferte", propOrder = {
    "nbOccurencesRisquesCouverts",
    "modeCalculDatePourAge",
    "codeUT",
    "risque"
})
public class GarantieOfferte
    extends ComposantProduit
{

    protected int nbOccurencesRisquesCouverts;
    @XmlElement(required = true)
    protected String modeCalculDatePourAge;
    @XmlElement(required = true)
    protected String codeUT;
    @XmlElement(required = true)
    protected List<Risque> risque;

    /**
     * Obtient la valeur de la propri�t� nbOccurencesRisquesCouverts.
     * 
     */
    public int getNbOccurencesRisquesCouverts() {
        return nbOccurencesRisquesCouverts;
    }

    /**
     * D�finit la valeur de la propri�t� nbOccurencesRisquesCouverts.
     * 
     */
    public void setNbOccurencesRisquesCouverts(int value) {
        this.nbOccurencesRisquesCouverts = value;
    }

    /**
     * Obtient la valeur de la propri�t� modeCalculDatePourAge.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModeCalculDatePourAge() {
        return modeCalculDatePourAge;
    }

    /**
     * D�finit la valeur de la propri�t� modeCalculDatePourAge.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModeCalculDatePourAge(String value) {
        this.modeCalculDatePourAge = value;
    }

    /**
     * Obtient la valeur de la propri�t� codeUT.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeUT() {
        return codeUT;
    }

    /**
     * D�finit la valeur de la propri�t� codeUT.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeUT(String value) {
        this.codeUT = value;
    }

    /**
     * Gets the value of the risque property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the risque property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRisque().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Risque }
     * 
     * 
     */
    public List<Risque> getRisque() {
        if (risque == null) {
            risque = new ArrayList<Risque>();
        }
        return this.risque;
    }

}
