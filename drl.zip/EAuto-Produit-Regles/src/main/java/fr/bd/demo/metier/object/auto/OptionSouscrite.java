//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.10 � 04:55:30 PM CEST 
//


package fr.bd.demo.metier.object.auto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import fr.bd.demo.metier.object.ComposantContrat;


/**
 * <p>Classe Java pour OptionSouscrite complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="OptionSouscrite">
 *   &lt;complexContent>
 *     &lt;extension base="{http://object.metier.demo.bd.fr/}ComposantContrat">
 *       &lt;sequence>
 *         &lt;element name="codeOption" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OptionSouscrite", propOrder = {
    "codeOption"
})
public class OptionSouscrite
    extends ComposantContrat
{

    @XmlElement(required = true)
    protected String codeOption;

    /**
     * Obtient la valeur de la propri�t� codeOption.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeOption() {
        return codeOption;
    }

    /**
     * D�finit la valeur de la propri�t� codeOption.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeOption(String value) {
        this.codeOption = value;
    }

}
