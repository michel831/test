//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.10 � 04:55:30 PM CEST 
//


package fr.bd.demo.metier.object.auto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import fr.bd.demo.metier.object.ObjetReference;


/**
 * <p>Classe Java pour SpecificationVehicule complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="SpecificationVehicule">
 *   &lt;complexContent>
 *     &lt;extension base="{http://object.metier.demo.bd.fr/}ObjetReference">
 *       &lt;sequence>
 *         &lt;element name="chargeUtile" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="encombrement" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="poidsBrut" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="volumeInterieur" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="indicateureHautePerformance" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="hautRisqueIV" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="nbPlacePassager" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="vehiculeDeCollection" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="indicateurVehiculeClassique" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="indicateurNumeroSerieGravure" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="vehicule" type="{http://auto.object.metier.demo.bd.fr/}Vehicule" maxOccurs="unbounded"/>
 *         &lt;element name="specificiteMoteur" type="{http://auto.object.metier.demo.bd.fr/}SpecificiteMoteur" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SpecificationVehicule", propOrder = {
    "chargeUtile",
    "encombrement",
    "poidsBrut",
    "volumeInterieur",
    "indicateureHautePerformance",
    "hautRisqueIV",
    "nbPlacePassager",
    "vehiculeDeCollection",
    "indicateurVehiculeClassique",
    "indicateurNumeroSerieGravure",
    "vehicule",
    "specificiteMoteur"
})
@XmlSeeAlso({
    SpecificationVehiculeTerrestre.class
})
public class SpecificationVehicule
    extends ObjetReference
{

    protected double chargeUtile;
    protected double encombrement;
    protected double poidsBrut;
    protected double volumeInterieur;
    protected int indicateureHautePerformance;
    protected boolean hautRisqueIV;
    protected int nbPlacePassager;
    protected boolean vehiculeDeCollection;
    protected int indicateurVehiculeClassique;
    protected int indicateurNumeroSerieGravure;
    @XmlElement(required = true)
    protected List<Vehicule> vehicule;
    @XmlElement(required = true)
    protected List<SpecificiteMoteur> specificiteMoteur;

    /**
     * Obtient la valeur de la propri�t� chargeUtile.
     * 
     */
    public double getChargeUtile() {
        return chargeUtile;
    }

    /**
     * D�finit la valeur de la propri�t� chargeUtile.
     * 
     */
    public void setChargeUtile(double value) {
        this.chargeUtile = value;
    }

    /**
     * Obtient la valeur de la propri�t� encombrement.
     * 
     */
    public double getEncombrement() {
        return encombrement;
    }

    /**
     * D�finit la valeur de la propri�t� encombrement.
     * 
     */
    public void setEncombrement(double value) {
        this.encombrement = value;
    }

    /**
     * Obtient la valeur de la propri�t� poidsBrut.
     * 
     */
    public double getPoidsBrut() {
        return poidsBrut;
    }

    /**
     * D�finit la valeur de la propri�t� poidsBrut.
     * 
     */
    public void setPoidsBrut(double value) {
        this.poidsBrut = value;
    }

    /**
     * Obtient la valeur de la propri�t� volumeInterieur.
     * 
     */
    public double getVolumeInterieur() {
        return volumeInterieur;
    }

    /**
     * D�finit la valeur de la propri�t� volumeInterieur.
     * 
     */
    public void setVolumeInterieur(double value) {
        this.volumeInterieur = value;
    }

    /**
     * Obtient la valeur de la propri�t� indicateureHautePerformance.
     * 
     */
    public int getIndicateureHautePerformance() {
        return indicateureHautePerformance;
    }

    /**
     * D�finit la valeur de la propri�t� indicateureHautePerformance.
     * 
     */
    public void setIndicateureHautePerformance(int value) {
        this.indicateureHautePerformance = value;
    }

    /**
     * Obtient la valeur de la propri�t� hautRisqueIV.
     * 
     */
    public boolean isHautRisqueIV() {
        return hautRisqueIV;
    }

    /**
     * D�finit la valeur de la propri�t� hautRisqueIV.
     * 
     */
    public void setHautRisqueIV(boolean value) {
        this.hautRisqueIV = value;
    }

    /**
     * Obtient la valeur de la propri�t� nbPlacePassager.
     * 
     */
    public int getNbPlacePassager() {
        return nbPlacePassager;
    }

    /**
     * D�finit la valeur de la propri�t� nbPlacePassager.
     * 
     */
    public void setNbPlacePassager(int value) {
        this.nbPlacePassager = value;
    }

    /**
     * Obtient la valeur de la propri�t� vehiculeDeCollection.
     * 
     */
    public boolean isVehiculeDeCollection() {
        return vehiculeDeCollection;
    }

    /**
     * D�finit la valeur de la propri�t� vehiculeDeCollection.
     * 
     */
    public void setVehiculeDeCollection(boolean value) {
        this.vehiculeDeCollection = value;
    }

    /**
     * Obtient la valeur de la propri�t� indicateurVehiculeClassique.
     * 
     */
    public int getIndicateurVehiculeClassique() {
        return indicateurVehiculeClassique;
    }

    /**
     * D�finit la valeur de la propri�t� indicateurVehiculeClassique.
     * 
     */
    public void setIndicateurVehiculeClassique(int value) {
        this.indicateurVehiculeClassique = value;
    }

    /**
     * Obtient la valeur de la propri�t� indicateurNumeroSerieGravure.
     * 
     */
    public int getIndicateurNumeroSerieGravure() {
        return indicateurNumeroSerieGravure;
    }

    /**
     * D�finit la valeur de la propri�t� indicateurNumeroSerieGravure.
     * 
     */
    public void setIndicateurNumeroSerieGravure(int value) {
        this.indicateurNumeroSerieGravure = value;
    }

    /**
     * Gets the value of the vehicule property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the vehicule property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getVehicule().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Vehicule }
     * 
     * 
     */
    public List<Vehicule> getVehicule() {
        if (vehicule == null) {
            vehicule = new ArrayList<Vehicule>();
        }
        return this.vehicule;
    }

    /**
     * Gets the value of the specificiteMoteur property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the specificiteMoteur property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSpecificiteMoteur().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SpecificiteMoteur }
     * 
     * 
     */
    public List<SpecificiteMoteur> getSpecificiteMoteur() {
        if (specificiteMoteur == null) {
            specificiteMoteur = new ArrayList<SpecificiteMoteur>();
        }
        return this.specificiteMoteur;
    }

}
