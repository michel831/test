//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.10 � 04:55:30 PM CEST 
//


package fr.bd.demo.metier.object.auto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour SpecificationVehiculeTerrestre complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="SpecificationVehiculeTerrestre">
 *   &lt;complexContent>
 *     &lt;extension base="{http://auto.object.metier.demo.bd.fr/}SpecificationVehicule">
 *       &lt;sequence>
 *         &lt;element name="nbCylindres" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="nbRouesMotrices" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="typeCeintures" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codeLocalisationCeintures" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codeTransmission" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="localisationAirbags" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="categorieVehicule" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="typeCarosserie" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="nbEssieux" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="vehiculeTerrestre" type="{http://auto.object.metier.demo.bd.fr/}VehiculeTerrestre" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SpecificationVehiculeTerrestre", propOrder = {
    "nbCylindres",
    "nbRouesMotrices",
    "typeCeintures",
    "codeLocalisationCeintures",
    "codeTransmission",
    "localisationAirbags",
    "categorieVehicule",
    "typeCarosserie",
    "nbEssieux",
    "vehiculeTerrestre"
})
public class SpecificationVehiculeTerrestre
    extends SpecificationVehicule
{

    protected int nbCylindres;
    protected int nbRouesMotrices;
    @XmlElement(required = true)
    protected String typeCeintures;
    @XmlElement(required = true)
    protected String codeLocalisationCeintures;
    @XmlElement(required = true)
    protected String codeTransmission;
    @XmlElement(required = true)
    protected String localisationAirbags;
    @XmlElement(required = true)
    protected String categorieVehicule;
    @XmlElement(required = true)
    protected String typeCarosserie;
    protected int nbEssieux;
    @XmlElement(required = true)
    protected List<VehiculeTerrestre> vehiculeTerrestre;

    /**
     * Obtient la valeur de la propri�t� nbCylindres.
     * 
     */
    public int getNbCylindres() {
        return nbCylindres;
    }

    /**
     * D�finit la valeur de la propri�t� nbCylindres.
     * 
     */
    public void setNbCylindres(int value) {
        this.nbCylindres = value;
    }

    /**
     * Obtient la valeur de la propri�t� nbRouesMotrices.
     * 
     */
    public int getNbRouesMotrices() {
        return nbRouesMotrices;
    }

    /**
     * D�finit la valeur de la propri�t� nbRouesMotrices.
     * 
     */
    public void setNbRouesMotrices(int value) {
        this.nbRouesMotrices = value;
    }

    /**
     * Obtient la valeur de la propri�t� typeCeintures.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeCeintures() {
        return typeCeintures;
    }

    /**
     * D�finit la valeur de la propri�t� typeCeintures.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeCeintures(String value) {
        this.typeCeintures = value;
    }

    /**
     * Obtient la valeur de la propri�t� codeLocalisationCeintures.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeLocalisationCeintures() {
        return codeLocalisationCeintures;
    }

    /**
     * D�finit la valeur de la propri�t� codeLocalisationCeintures.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeLocalisationCeintures(String value) {
        this.codeLocalisationCeintures = value;
    }

    /**
     * Obtient la valeur de la propri�t� codeTransmission.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeTransmission() {
        return codeTransmission;
    }

    /**
     * D�finit la valeur de la propri�t� codeTransmission.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeTransmission(String value) {
        this.codeTransmission = value;
    }

    /**
     * Obtient la valeur de la propri�t� localisationAirbags.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalisationAirbags() {
        return localisationAirbags;
    }

    /**
     * D�finit la valeur de la propri�t� localisationAirbags.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalisationAirbags(String value) {
        this.localisationAirbags = value;
    }

    /**
     * Obtient la valeur de la propri�t� categorieVehicule.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCategorieVehicule() {
        return categorieVehicule;
    }

    /**
     * D�finit la valeur de la propri�t� categorieVehicule.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCategorieVehicule(String value) {
        this.categorieVehicule = value;
    }

    /**
     * Obtient la valeur de la propri�t� typeCarosserie.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeCarosserie() {
        return typeCarosserie;
    }

    /**
     * D�finit la valeur de la propri�t� typeCarosserie.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeCarosserie(String value) {
        this.typeCarosserie = value;
    }

    /**
     * Obtient la valeur de la propri�t� nbEssieux.
     * 
     */
    public int getNbEssieux() {
        return nbEssieux;
    }

    /**
     * D�finit la valeur de la propri�t� nbEssieux.
     * 
     */
    public void setNbEssieux(int value) {
        this.nbEssieux = value;
    }

    /**
     * Gets the value of the vehiculeTerrestre property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the vehiculeTerrestre property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getVehiculeTerrestre().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link VehiculeTerrestre }
     * 
     * 
     */
    public List<VehiculeTerrestre> getVehiculeTerrestre() {
        if (vehiculeTerrestre == null) {
            vehiculeTerrestre = new ArrayList<VehiculeTerrestre>();
        }
        return this.vehiculeTerrestre;
    }

}
