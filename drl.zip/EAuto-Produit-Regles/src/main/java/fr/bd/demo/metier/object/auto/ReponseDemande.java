//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.10 � 04:55:30 PM CEST 
//


package fr.bd.demo.metier.object.auto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ReponseDemande complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ReponseDemande">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="statutEligibilite" type="{http://auto.object.metier.demo.bd.fr/}StatutDemande"/>
 *         &lt;element name="raisons" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ReponseDemande", propOrder = {
    "statutEligibilite",
    "raisons"
})
public class ReponseDemande {

    @XmlElement(required = true)
    protected StatutDemande statutEligibilite;
    protected List<String> raisons;

    /**
     * Obtient la valeur de la propri�t� statutEligibilite.
     * 
     * @return
     *     possible object is
     *     {@link StatutDemande }
     *     
     */
    public StatutDemande getStatutEligibilite() {
        return statutEligibilite;
    }

    /**
     * D�finit la valeur de la propri�t� statutEligibilite.
     * 
     * @param value
     *     allowed object is
     *     {@link StatutDemande }
     *     
     */
    public void setStatutEligibilite(StatutDemande value) {
        this.statutEligibilite = value;
    }

    /**
     * Gets the value of the raisons property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the raisons property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRaisons().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getRaisons() {
        if (raisons == null) {
            raisons = new ArrayList<String>();
        }
        return this.raisons;
    }

}
