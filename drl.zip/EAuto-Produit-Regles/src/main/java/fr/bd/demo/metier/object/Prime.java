//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.10 � 04:55:30 PM CEST 
//


package fr.bd.demo.metier.object;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour Prime complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="Prime">
 *   &lt;complexContent>
 *     &lt;extension base="{http://object.metier.demo.bd.fr/}ObjetReference">
 *       &lt;sequence>
 *         &lt;element name="Taxe" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="HT" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="TTC" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="codeMethodeCalcul" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="montant" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="nature" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Prime", propOrder = {
    "taxe",
    "ht",
    "ttc",
    "codeMethodeCalcul",
    "montant",
    "nature"
})
public class Prime
    extends ObjetReference
{

    @XmlElement(name = "Taxe")
    protected double taxe;
    @XmlElement(name = "HT")
    protected double ht;
    @XmlElement(name = "TTC")
    protected double ttc;
    @XmlElement(required = true)
    protected String codeMethodeCalcul;
    protected double montant;
    @XmlElement(required = true)
    protected String nature;

    /**
     * Obtient la valeur de la propri�t� taxe.
     * 
     */
    public double getTaxe() {
        return taxe;
    }

    /**
     * D�finit la valeur de la propri�t� taxe.
     * 
     */
    public void setTaxe(double value) {
        this.taxe = value;
    }

    /**
     * Obtient la valeur de la propri�t� ht.
     * 
     */
    public double getHT() {
        return ht;
    }

    /**
     * D�finit la valeur de la propri�t� ht.
     * 
     */
    public void setHT(double value) {
        this.ht = value;
    }

    /**
     * Obtient la valeur de la propri�t� ttc.
     * 
     */
    public double getTTC() {
        return ttc;
    }

    /**
     * D�finit la valeur de la propri�t� ttc.
     * 
     */
    public void setTTC(double value) {
        this.ttc = value;
    }

    /**
     * Obtient la valeur de la propri�t� codeMethodeCalcul.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeMethodeCalcul() {
        return codeMethodeCalcul;
    }

    /**
     * D�finit la valeur de la propri�t� codeMethodeCalcul.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeMethodeCalcul(String value) {
        this.codeMethodeCalcul = value;
    }

    /**
     * Obtient la valeur de la propri�t� montant.
     * 
     */
    public double getMontant() {
        return montant;
    }

    /**
     * D�finit la valeur de la propri�t� montant.
     * 
     */
    public void setMontant(double value) {
        this.montant = value;
    }

    /**
     * Obtient la valeur de la propri�t� nature.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNature() {
        return nature;
    }

    /**
     * D�finit la valeur de la propri�t� nature.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNature(String value) {
        this.nature = value;
    }

}
