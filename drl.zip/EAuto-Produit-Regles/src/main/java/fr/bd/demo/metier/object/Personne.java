//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.10 � 04:55:30 PM CEST 
//


package fr.bd.demo.metier.object;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import fr.bd.demo.metier.object.auto.PersonnePhysique;
import org.w3._2001.xmlschema.Adapter1;


/**
 * <p>Classe Java pour Personne complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="Personne">
 *   &lt;complexContent>
 *     &lt;extension base="{http://object.metier.demo.bd.fr/}ObjetReference">
 *       &lt;sequence>
 *         &lt;element name="dateDeces" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="dateDisparition" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="dateNaissance" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="decede" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="disparu" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="languePrincipale" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="nomFamille" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="prenom" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="qualite" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="suffixe" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="numTelephone" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="typeTelephone" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="adresseMail" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codePostal" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="boitePostal" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ville" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="nomBatiment" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="etage" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="numRue" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="nomRue" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Personne", propOrder = {
    "dateDeces",
    "dateDisparition",
    "dateNaissance",
    "decede",
    "disparu",
    "languePrincipale",
    "nomFamille",
    "prenom",
    "qualite",
    "suffixe",
    "numTelephone",
    "typeTelephone",
    "adresseMail",
    "codePostal",
    "boitePostal",
    "ville",
    "nomBatiment",
    "etage",
    "numRue",
    "nomRue"
})
@XmlSeeAlso({
    PersonnePhysique.class
})
public class Personne
    extends ObjetReference
{

    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "date")
    protected Date dateDeces;
    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "date")
    protected Date dateDisparition;
    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "date")
    protected Date dateNaissance;
    protected boolean decede;
    protected boolean disparu;
    @XmlElement(required = true)
    protected String languePrincipale;
    @XmlElement(required = true)
    protected String nomFamille;
    @XmlElement(required = true)
    protected String prenom;
    @XmlElement(required = true)
    protected String qualite;
    @XmlElement(required = true)
    protected String suffixe;
    @XmlElement(required = true)
    protected String numTelephone;
    @XmlElement(required = true)
    protected String typeTelephone;
    @XmlElement(required = true)
    protected String adresseMail;
    @XmlElement(required = true)
    protected String codePostal;
    @XmlElement(required = true)
    protected String boitePostal;
    @XmlElement(required = true)
    protected String ville;
    @XmlElement(required = true)
    protected String nomBatiment;
    protected int etage;
    protected int numRue;
    @XmlElement(required = true)
    protected String nomRue;

    /**
     * Obtient la valeur de la propri�t� dateDeces.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDateDeces() {
        return dateDeces;
    }

    /**
     * D�finit la valeur de la propri�t� dateDeces.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateDeces(Date value) {
        this.dateDeces = value;
    }

    /**
     * Obtient la valeur de la propri�t� dateDisparition.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDateDisparition() {
        return dateDisparition;
    }

    /**
     * D�finit la valeur de la propri�t� dateDisparition.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateDisparition(Date value) {
        this.dateDisparition = value;
    }

    /**
     * Obtient la valeur de la propri�t� dateNaissance.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDateNaissance() {
        return dateNaissance;
    }

    /**
     * D�finit la valeur de la propri�t� dateNaissance.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateNaissance(Date value) {
        this.dateNaissance = value;
    }

    /**
     * Obtient la valeur de la propri�t� decede.
     * 
     */
    public boolean isDecede() {
        return decede;
    }

    /**
     * D�finit la valeur de la propri�t� decede.
     * 
     */
    public void setDecede(boolean value) {
        this.decede = value;
    }

    /**
     * Obtient la valeur de la propri�t� disparu.
     * 
     */
    public boolean isDisparu() {
        return disparu;
    }

    /**
     * D�finit la valeur de la propri�t� disparu.
     * 
     */
    public void setDisparu(boolean value) {
        this.disparu = value;
    }

    /**
     * Obtient la valeur de la propri�t� languePrincipale.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLanguePrincipale() {
        return languePrincipale;
    }

    /**
     * D�finit la valeur de la propri�t� languePrincipale.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLanguePrincipale(String value) {
        this.languePrincipale = value;
    }

    /**
     * Obtient la valeur de la propri�t� nomFamille.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomFamille() {
        return nomFamille;
    }

    /**
     * D�finit la valeur de la propri�t� nomFamille.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomFamille(String value) {
        this.nomFamille = value;
    }

    /**
     * Obtient la valeur de la propri�t� prenom.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrenom() {
        return prenom;
    }

    /**
     * D�finit la valeur de la propri�t� prenom.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrenom(String value) {
        this.prenom = value;
    }

    /**
     * Obtient la valeur de la propri�t� qualite.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQualite() {
        return qualite;
    }

    /**
     * D�finit la valeur de la propri�t� qualite.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQualite(String value) {
        this.qualite = value;
    }

    /**
     * Obtient la valeur de la propri�t� suffixe.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuffixe() {
        return suffixe;
    }

    /**
     * D�finit la valeur de la propri�t� suffixe.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuffixe(String value) {
        this.suffixe = value;
    }

    /**
     * Obtient la valeur de la propri�t� numTelephone.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumTelephone() {
        return numTelephone;
    }

    /**
     * D�finit la valeur de la propri�t� numTelephone.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumTelephone(String value) {
        this.numTelephone = value;
    }

    /**
     * Obtient la valeur de la propri�t� typeTelephone.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeTelephone() {
        return typeTelephone;
    }

    /**
     * D�finit la valeur de la propri�t� typeTelephone.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeTelephone(String value) {
        this.typeTelephone = value;
    }

    /**
     * Obtient la valeur de la propri�t� adresseMail.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdresseMail() {
        return adresseMail;
    }

    /**
     * D�finit la valeur de la propri�t� adresseMail.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdresseMail(String value) {
        this.adresseMail = value;
    }

    /**
     * Obtient la valeur de la propri�t� codePostal.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodePostal() {
        return codePostal;
    }

    /**
     * D�finit la valeur de la propri�t� codePostal.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodePostal(String value) {
        this.codePostal = value;
    }

    /**
     * Obtient la valeur de la propri�t� boitePostal.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBoitePostal() {
        return boitePostal;
    }

    /**
     * D�finit la valeur de la propri�t� boitePostal.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBoitePostal(String value) {
        this.boitePostal = value;
    }

    /**
     * Obtient la valeur de la propri�t� ville.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVille() {
        return ville;
    }

    /**
     * D�finit la valeur de la propri�t� ville.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVille(String value) {
        this.ville = value;
    }

    /**
     * Obtient la valeur de la propri�t� nomBatiment.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomBatiment() {
        return nomBatiment;
    }

    /**
     * D�finit la valeur de la propri�t� nomBatiment.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomBatiment(String value) {
        this.nomBatiment = value;
    }

    /**
     * Obtient la valeur de la propri�t� etage.
     * 
     */
    public int getEtage() {
        return etage;
    }

    /**
     * D�finit la valeur de la propri�t� etage.
     * 
     */
    public void setEtage(int value) {
        this.etage = value;
    }

    /**
     * Obtient la valeur de la propri�t� numRue.
     * 
     */
    public int getNumRue() {
        return numRue;
    }

    /**
     * D�finit la valeur de la propri�t� numRue.
     * 
     */
    public void setNumRue(int value) {
        this.numRue = value;
    }

    /**
     * Obtient la valeur de la propri�t� nomRue.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomRue() {
        return nomRue;
    }

    /**
     * D�finit la valeur de la propri�t� nomRue.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomRue(String value) {
        this.nomRue = value;
    }

}
