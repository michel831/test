//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.10 � 04:55:30 PM CEST 
//


package fr.bd.demo.metier.object;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import fr.bd.demo.metier.object.auto.OptionProduit;


/**
 * <p>Classe Java pour DefinitionProduit complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="DefinitionProduit">
 *   &lt;complexContent>
 *     &lt;extension base="{http://object.metier.demo.bd.fr/}ObjetReference">
 *       &lt;sequence>
 *         &lt;element name="statut" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="nom" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="key" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="raisonChangementStatut" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="estCommercialisable" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsComposedOf" type="{http://object.metier.demo.bd.fr/}DefinitionProduit" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DefinitionProduit", propOrder = {
    "statut",
    "nom",
    "description",
    "key",
    "raisonChangementStatut",
    "estCommercialisable",
    "isComposedOf"
})
@XmlSeeAlso({
    OptionProduit.class,
    ComposantProduit.class
})
public class DefinitionProduit
    extends ObjetReference
{

    @XmlElement(required = true)
    protected String statut;
    @XmlElement(required = true)
    protected String nom;
    @XmlElement(required = true)
    protected String description;
    @XmlElement(required = true)
    protected String key;
    @XmlElement(required = true)
    protected String raisonChangementStatut;
    protected boolean estCommercialisable;
    @XmlElement(name = "IsComposedOf")
    protected List<DefinitionProduit> isComposedOf;

    /**
     * Obtient la valeur de la propri�t� statut.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatut() {
        return statut;
    }

    /**
     * D�finit la valeur de la propri�t� statut.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatut(String value) {
        this.statut = value;
    }

    /**
     * Obtient la valeur de la propri�t� nom.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNom() {
        return nom;
    }

    /**
     * D�finit la valeur de la propri�t� nom.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNom(String value) {
        this.nom = value;
    }

    /**
     * Obtient la valeur de la propri�t� description.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * D�finit la valeur de la propri�t� description.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Obtient la valeur de la propri�t� key.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKey() {
        return key;
    }

    /**
     * D�finit la valeur de la propri�t� key.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKey(String value) {
        this.key = value;
    }

    /**
     * Obtient la valeur de la propri�t� raisonChangementStatut.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRaisonChangementStatut() {
        return raisonChangementStatut;
    }

    /**
     * D�finit la valeur de la propri�t� raisonChangementStatut.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRaisonChangementStatut(String value) {
        this.raisonChangementStatut = value;
    }

    /**
     * Obtient la valeur de la propri�t� estCommercialisable.
     * 
     */
    public boolean isEstCommercialisable() {
        return estCommercialisable;
    }

    /**
     * D�finit la valeur de la propri�t� estCommercialisable.
     * 
     */
    public void setEstCommercialisable(boolean value) {
        this.estCommercialisable = value;
    }

    /**
     * Gets the value of the isComposedOf property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the isComposedOf property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIsComposedOf().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DefinitionProduit }
     * 
     * 
     */
    public List<DefinitionProduit> getIsComposedOf() {
        if (isComposedOf == null) {
            isComposedOf = new ArrayList<DefinitionProduit>();
        }
        return this.isComposedOf;
    }

}
