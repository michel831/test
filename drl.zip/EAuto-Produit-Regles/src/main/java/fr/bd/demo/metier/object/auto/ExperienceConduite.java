//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.10 � 04:55:30 PM CEST 
//


package fr.bd.demo.metier.object.auto;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import org.w3._2001.xmlschema.Adapter1;


/**
 * <p>Classe Java pour ExperienceConduite complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ExperienceConduite">
 *   &lt;complexContent>
 *     &lt;extension base="{http://auto.object.metier.demo.bd.fr/}DetailsPersonnePhysique">
 *       &lt;sequence>
 *         &lt;element name="dateObtentionPermis" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="permisParConduiteAccompagnee" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="bonusMalus" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="dateObtentionBM" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="dateObtentionBM50" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="dureeDetentionDernierVehicule" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="dureeInterruptionAssurance" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="dateFinInterruptionAssurance" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="dateResiliationDernierContrat" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="indicateurResiliationParCompagniePrecedente" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="nbSinistresSur3Ans" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="nbSinistresSur5Ans" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="alcoolemieAuVolant" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="dateDerneireMaj" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ExperienceConduite", propOrder = {
    "dateObtentionPermis",
    "permisParConduiteAccompagnee",
    "bonusMalus",
    "dateObtentionBM",
    "dateObtentionBM50",
    "dureeDetentionDernierVehicule",
    "dureeInterruptionAssurance",
    "dateFinInterruptionAssurance",
    "dateResiliationDernierContrat",
    "indicateurResiliationParCompagniePrecedente",
    "nbSinistresSur3Ans",
    "nbSinistresSur5Ans",
    "alcoolemieAuVolant",
    "dateDerneireMaj"
})
public class ExperienceConduite
    extends DetailsPersonnePhysique
{

    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "date")
    protected Date dateObtentionPermis;
    protected boolean permisParConduiteAccompagnee;
    protected int bonusMalus;
    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "date")
    protected Date dateObtentionBM;
    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "date")
    protected Date dateObtentionBM50;
    protected int dureeDetentionDernierVehicule;
    protected int dureeInterruptionAssurance;
    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "date")
    protected Date dateFinInterruptionAssurance;
    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "date")
    protected Date dateResiliationDernierContrat;
    protected boolean indicateurResiliationParCompagniePrecedente;
    protected int nbSinistresSur3Ans;
    protected int nbSinistresSur5Ans;
    protected boolean alcoolemieAuVolant;
    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "date")
    protected Date dateDerneireMaj;

    /**
     * Obtient la valeur de la propri�t� dateObtentionPermis.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDateObtentionPermis() {
        return dateObtentionPermis;
    }

    /**
     * D�finit la valeur de la propri�t� dateObtentionPermis.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateObtentionPermis(Date value) {
        this.dateObtentionPermis = value;
    }

    /**
     * Obtient la valeur de la propri�t� permisParConduiteAccompagnee.
     * 
     */
    public boolean isPermisParConduiteAccompagnee() {
        return permisParConduiteAccompagnee;
    }

    /**
     * D�finit la valeur de la propri�t� permisParConduiteAccompagnee.
     * 
     */
    public void setPermisParConduiteAccompagnee(boolean value) {
        this.permisParConduiteAccompagnee = value;
    }

    /**
     * Obtient la valeur de la propri�t� bonusMalus.
     * 
     */
    public int getBonusMalus() {
        return bonusMalus;
    }

    /**
     * D�finit la valeur de la propri�t� bonusMalus.
     * 
     */
    public void setBonusMalus(int value) {
        this.bonusMalus = value;
    }

    /**
     * Obtient la valeur de la propri�t� dateObtentionBM.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDateObtentionBM() {
        return dateObtentionBM;
    }

    /**
     * D�finit la valeur de la propri�t� dateObtentionBM.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateObtentionBM(Date value) {
        this.dateObtentionBM = value;
    }

    /**
     * Obtient la valeur de la propri�t� dateObtentionBM50.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDateObtentionBM50() {
        return dateObtentionBM50;
    }

    /**
     * D�finit la valeur de la propri�t� dateObtentionBM50.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateObtentionBM50(Date value) {
        this.dateObtentionBM50 = value;
    }

    /**
     * Obtient la valeur de la propri�t� dureeDetentionDernierVehicule.
     * 
     */
    public int getDureeDetentionDernierVehicule() {
        return dureeDetentionDernierVehicule;
    }

    /**
     * D�finit la valeur de la propri�t� dureeDetentionDernierVehicule.
     * 
     */
    public void setDureeDetentionDernierVehicule(int value) {
        this.dureeDetentionDernierVehicule = value;
    }

    /**
     * Obtient la valeur de la propri�t� dureeInterruptionAssurance.
     * 
     */
    public int getDureeInterruptionAssurance() {
        return dureeInterruptionAssurance;
    }

    /**
     * D�finit la valeur de la propri�t� dureeInterruptionAssurance.
     * 
     */
    public void setDureeInterruptionAssurance(int value) {
        this.dureeInterruptionAssurance = value;
    }

    /**
     * Obtient la valeur de la propri�t� dateFinInterruptionAssurance.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDateFinInterruptionAssurance() {
        return dateFinInterruptionAssurance;
    }

    /**
     * D�finit la valeur de la propri�t� dateFinInterruptionAssurance.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateFinInterruptionAssurance(Date value) {
        this.dateFinInterruptionAssurance = value;
    }

    /**
     * Obtient la valeur de la propri�t� dateResiliationDernierContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDateResiliationDernierContrat() {
        return dateResiliationDernierContrat;
    }

    /**
     * D�finit la valeur de la propri�t� dateResiliationDernierContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateResiliationDernierContrat(Date value) {
        this.dateResiliationDernierContrat = value;
    }

    /**
     * Obtient la valeur de la propri�t� indicateurResiliationParCompagniePrecedente.
     * 
     */
    public boolean isIndicateurResiliationParCompagniePrecedente() {
        return indicateurResiliationParCompagniePrecedente;
    }

    /**
     * D�finit la valeur de la propri�t� indicateurResiliationParCompagniePrecedente.
     * 
     */
    public void setIndicateurResiliationParCompagniePrecedente(boolean value) {
        this.indicateurResiliationParCompagniePrecedente = value;
    }

    /**
     * Obtient la valeur de la propri�t� nbSinistresSur3Ans.
     * 
     */
    public int getNbSinistresSur3Ans() {
        return nbSinistresSur3Ans;
    }

    /**
     * D�finit la valeur de la propri�t� nbSinistresSur3Ans.
     * 
     */
    public void setNbSinistresSur3Ans(int value) {
        this.nbSinistresSur3Ans = value;
    }

    /**
     * Obtient la valeur de la propri�t� nbSinistresSur5Ans.
     * 
     */
    public int getNbSinistresSur5Ans() {
        return nbSinistresSur5Ans;
    }

    /**
     * D�finit la valeur de la propri�t� nbSinistresSur5Ans.
     * 
     */
    public void setNbSinistresSur5Ans(int value) {
        this.nbSinistresSur5Ans = value;
    }

    /**
     * Obtient la valeur de la propri�t� alcoolemieAuVolant.
     * 
     */
    public boolean isAlcoolemieAuVolant() {
        return alcoolemieAuVolant;
    }

    /**
     * D�finit la valeur de la propri�t� alcoolemieAuVolant.
     * 
     */
    public void setAlcoolemieAuVolant(boolean value) {
        this.alcoolemieAuVolant = value;
    }

    /**
     * Obtient la valeur de la propri�t� dateDerneireMaj.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDateDerneireMaj() {
        return dateDerneireMaj;
    }

    /**
     * D�finit la valeur de la propri�t� dateDerneireMaj.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateDerneireMaj(Date value) {
        this.dateDerneireMaj = value;
    }

}
