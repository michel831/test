//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.10 � 04:55:30 PM CEST 
//


package fr.bd.demo.metier.object.auto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import fr.bd.demo.metier.object.Contrat;


/**
 * <p>Classe Java pour ContratServiceFinancier complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ContratServiceFinancier">
 *   &lt;complexContent>
 *     &lt;extension base="{http://object.metier.demo.bd.fr/}Contrat">
 *       &lt;sequence>
 *         &lt;element name="statutFiscal" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="indicateurCoSouscription" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContratServiceFinancier", propOrder = {
    "statutFiscal",
    "indicateurCoSouscription"
})
@XmlSeeAlso({
    ContratAssurance.class
})
public class ContratServiceFinancier
    extends Contrat
{

    @XmlElement(required = true)
    protected String statutFiscal;
    protected boolean indicateurCoSouscription;

    /**
     * Obtient la valeur de la propri�t� statutFiscal.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatutFiscal() {
        return statutFiscal;
    }

    /**
     * D�finit la valeur de la propri�t� statutFiscal.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatutFiscal(String value) {
        this.statutFiscal = value;
    }

    /**
     * Obtient la valeur de la propri�t� indicateurCoSouscription.
     * 
     */
    public boolean isIndicateurCoSouscription() {
        return indicateurCoSouscription;
    }

    /**
     * D�finit la valeur de la propri�t� indicateurCoSouscription.
     * 
     */
    public void setIndicateurCoSouscription(boolean value) {
        this.indicateurCoSouscription = value;
    }

}
