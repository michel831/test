//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.10 � 04:55:30 PM CEST 
//


package fr.bd.demo.metier.object.auto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import fr.bd.demo.metier.object.Personne;


/**
 * <p>Classe Java pour ContratAssurance complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ContratAssurance">
 *   &lt;complexContent>
 *     &lt;extension base="{http://auto.object.metier.demo.bd.fr/}ContratServiceFinancier">
 *       &lt;sequence>
 *         &lt;element name="indicateurRenouvellement" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="codeFamille" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codeBranche" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codeProduitInterne" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="conducteurs" type="{http://object.metier.demo.bd.fr/}Personne" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContratAssurance", propOrder = {
    "indicateurRenouvellement",
    "codeFamille",
    "codeBranche",
    "codeProduitInterne",
    "conducteurs"
})
public class ContratAssurance
    extends ContratServiceFinancier
{

    protected boolean indicateurRenouvellement;
    @XmlElement(required = true)
    protected String codeFamille;
    @XmlElement(required = true)
    protected String codeBranche;
    @XmlElement(required = true)
    protected String codeProduitInterne;
    @XmlElement(required = true)
    protected List<Personne> conducteurs;

    /**
     * Obtient la valeur de la propri�t� indicateurRenouvellement.
     * 
     */
    public boolean isIndicateurRenouvellement() {
        return indicateurRenouvellement;
    }

    /**
     * D�finit la valeur de la propri�t� indicateurRenouvellement.
     * 
     */
    public void setIndicateurRenouvellement(boolean value) {
        this.indicateurRenouvellement = value;
    }

    /**
     * Obtient la valeur de la propri�t� codeFamille.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeFamille() {
        return codeFamille;
    }

    /**
     * D�finit la valeur de la propri�t� codeFamille.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeFamille(String value) {
        this.codeFamille = value;
    }

    /**
     * Obtient la valeur de la propri�t� codeBranche.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeBranche() {
        return codeBranche;
    }

    /**
     * D�finit la valeur de la propri�t� codeBranche.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeBranche(String value) {
        this.codeBranche = value;
    }

    /**
     * Obtient la valeur de la propri�t� codeProduitInterne.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeProduitInterne() {
        return codeProduitInterne;
    }

    /**
     * D�finit la valeur de la propri�t� codeProduitInterne.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeProduitInterne(String value) {
        this.codeProduitInterne = value;
    }

    /**
     * Gets the value of the conducteurs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the conducteurs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getConducteurs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Personne }
     * 
     * 
     */
    public List<Personne> getConducteurs() {
        if (conducteurs == null) {
            conducteurs = new ArrayList<Personne>();
        }
        return this.conducteurs;
    }

}
