//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.10 � 04:55:30 PM CEST 
//


package fr.bd.demo.metier.object;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import fr.bd.demo.metier.object.auto.GarantieOfferte;


/**
 * <p>Classe Java pour ComposantProduit complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ComposantProduit">
 *   &lt;complexContent>
 *     &lt;extension base="{http://object.metier.demo.bd.fr/}DefinitionProduit">
 *       &lt;sequence>
 *         &lt;element name="parametreProduit" type="{http://object.metier.demo.bd.fr/}ParametreProduit" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ComposantProduit", propOrder = {
    "parametreProduit"
})
@XmlSeeAlso({
    Clause.class,
    GarantieOfferte.class,
    CaracteristiqueProduit.class
})
public class ComposantProduit
    extends DefinitionProduit
{

    @XmlElement(required = true)
    protected List<ParametreProduit> parametreProduit;

    /**
     * Gets the value of the parametreProduit property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the parametreProduit property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getParametreProduit().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ParametreProduit }
     * 
     * 
     */
    public List<ParametreProduit> getParametreProduit() {
        if (parametreProduit == null) {
            parametreProduit = new ArrayList<ParametreProduit>();
        }
        return this.parametreProduit;
    }

}
