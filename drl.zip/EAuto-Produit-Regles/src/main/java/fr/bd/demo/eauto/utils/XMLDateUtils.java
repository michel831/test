package fr.bd.demo.eauto.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class XMLDateUtils {

	public static final DateFormat DATE_FORMAT = new SimpleDateFormat(
			"dd/MM/yyyy");

	public static Date parseDate(String value) {
		try {
			return DATE_FORMAT.parse(value);
		} catch (ParseException e) {
			return null;
		}
	}

	public static String printDate(Date value) {
		if (value == null) {
			return "";
		}
		return DATE_FORMAT.format(value);
	}

}
