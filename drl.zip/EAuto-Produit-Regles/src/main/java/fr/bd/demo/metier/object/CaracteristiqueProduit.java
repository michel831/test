//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.10 � 04:55:30 PM CEST 
//


package fr.bd.demo.metier.object;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import fr.bd.demo.metier.object.auto.OptionPaiement;
import fr.bd.demo.metier.object.auto.ServiceOffert;


/**
 * <p>Classe Java pour CaracteristiqueProduit complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CaracteristiqueProduit">
 *   &lt;complexContent>
 *     &lt;extension base="{http://object.metier.demo.bd.fr/}ComposantProduit">
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CaracteristiqueProduit")
@XmlSeeAlso({
    OptionPaiement.class,
    ServiceOffert.class
})
public class CaracteristiqueProduit
    extends ComposantProduit
{


}
