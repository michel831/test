//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.10 � 04:55:30 PM CEST 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://object.metier.demo.bd.fr/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package fr.bd.demo.metier.object;
