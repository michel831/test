//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.10 � 04:55:30 PM CEST 
//


package fr.bd.demo.metier.object.auto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import fr.bd.demo.metier.object.ObjetReference;


/**
 * <p>Classe Java pour SpecificiteMoteur complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="SpecificiteMoteur">
 *   &lt;complexContent>
 *     &lt;extension base="{http://object.metier.demo.bd.fr/}ObjetReference">
 *       &lt;sequence>
 *         &lt;element name="typeCarburant" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="typeMoteur" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="puissanceCV" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="cylindre" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="typeInjection" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="allumage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="specificationVehicule" type="{http://auto.object.metier.demo.bd.fr/}SpecificationVehicule" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SpecificiteMoteur", propOrder = {
    "typeCarburant",
    "typeMoteur",
    "puissanceCV",
    "cylindre",
    "typeInjection",
    "allumage",
    "specificationVehicule"
})
public class SpecificiteMoteur
    extends ObjetReference
{

    @XmlElement(required = true)
    protected String typeCarburant;
    @XmlElement(required = true)
    protected String typeMoteur;
    protected int puissanceCV;
    protected int cylindre;
    @XmlElement(required = true)
    protected String typeInjection;
    @XmlElement(required = true)
    protected String allumage;
    @XmlElement(required = true)
    protected List<SpecificationVehicule> specificationVehicule;

    /**
     * Obtient la valeur de la propri�t� typeCarburant.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeCarburant() {
        return typeCarburant;
    }

    /**
     * D�finit la valeur de la propri�t� typeCarburant.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeCarburant(String value) {
        this.typeCarburant = value;
    }

    /**
     * Obtient la valeur de la propri�t� typeMoteur.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeMoteur() {
        return typeMoteur;
    }

    /**
     * D�finit la valeur de la propri�t� typeMoteur.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeMoteur(String value) {
        this.typeMoteur = value;
    }

    /**
     * Obtient la valeur de la propri�t� puissanceCV.
     * 
     */
    public int getPuissanceCV() {
        return puissanceCV;
    }

    /**
     * D�finit la valeur de la propri�t� puissanceCV.
     * 
     */
    public void setPuissanceCV(int value) {
        this.puissanceCV = value;
    }

    /**
     * Obtient la valeur de la propri�t� cylindre.
     * 
     */
    public int getCylindre() {
        return cylindre;
    }

    /**
     * D�finit la valeur de la propri�t� cylindre.
     * 
     */
    public void setCylindre(int value) {
        this.cylindre = value;
    }

    /**
     * Obtient la valeur de la propri�t� typeInjection.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeInjection() {
        return typeInjection;
    }

    /**
     * D�finit la valeur de la propri�t� typeInjection.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeInjection(String value) {
        this.typeInjection = value;
    }

    /**
     * Obtient la valeur de la propri�t� allumage.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllumage() {
        return allumage;
    }

    /**
     * D�finit la valeur de la propri�t� allumage.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllumage(String value) {
        this.allumage = value;
    }

    /**
     * Gets the value of the specificationVehicule property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the specificationVehicule property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSpecificationVehicule().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SpecificationVehicule }
     * 
     * 
     */
    public List<SpecificationVehicule> getSpecificationVehicule() {
        if (specificationVehicule == null) {
            specificationVehicule = new ArrayList<SpecificationVehicule>();
        }
        return this.specificationVehicule;
    }

}
