//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.10 � 04:55:30 PM CEST 
//


package fr.bd.demo.metier.object.auto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import fr.bd.demo.metier.object.Personne;


/**
 * <p>Classe Java pour PersonnePhysique complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="PersonnePhysique">
 *   &lt;complexContent>
 *     &lt;extension base="{http://object.metier.demo.bd.fr/}Personne">
 *       &lt;sequence>
 *         &lt;element name="detailsPersonnePhysique" type="{http://auto.object.metier.demo.bd.fr/}DetailsPersonnePhysique" maxOccurs="unbounded"/>
 *         &lt;element name="infractionConduite" type="{http://auto.object.metier.demo.bd.fr/}InfractionConduite" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PersonnePhysique", propOrder = {
    "detailsPersonnePhysique",
    "infractionConduite"
})
public class PersonnePhysique
    extends Personne
{

    @XmlElement(required = true)
    protected List<DetailsPersonnePhysique> detailsPersonnePhysique;
    protected List<InfractionConduite> infractionConduite;

    /**
     * Gets the value of the detailsPersonnePhysique property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the detailsPersonnePhysique property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDetailsPersonnePhysique().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DetailsPersonnePhysique }
     * 
     * 
     */
    public List<DetailsPersonnePhysique> getDetailsPersonnePhysique() {
        if (detailsPersonnePhysique == null) {
            detailsPersonnePhysique = new ArrayList<DetailsPersonnePhysique>();
        }
        return this.detailsPersonnePhysique;
    }

    /**
     * Gets the value of the infractionConduite property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the infractionConduite property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInfractionConduite().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InfractionConduite }
     * 
     * 
     */
    public List<InfractionConduite> getInfractionConduite() {
        if (infractionConduite == null) {
            infractionConduite = new ArrayList<InfractionConduite>();
        }
        return this.infractionConduite;
    }

}
