//
// Ce fichier a �t� g�n�r� par l'impl�mentation de r�f�rence JavaTM Architecture for XML Binding (JAXB), v2.2.5-2 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apport�e � ce fichier sera perdue lors de la recompilation du sch�ma source. 
// G�n�r� le : 2012.09.10 � 04:55:30 PM CEST 
//


package fr.bd.demo.metier.object.auto;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import org.w3._2001.xmlschema.Adapter1;


/**
 * <p>Classe Java pour Voiture complex type.
 * 
 * <p>Le fragment de sch�ma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="Voiture">
 *   &lt;complexContent>
 *     &lt;extension base="{http://auto.object.metier.demo.bd.fr/}VehiculeTerrestre">
 *       &lt;sequence>
 *         &lt;element name="immatriculation" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="dateCarteGrise" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="dateProchainControleTechnique" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="modeAchat" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Voiture", propOrder = {
    "immatriculation",
    "dateCarteGrise",
    "dateProchainControleTechnique",
    "modeAchat"
})
public class Voiture
    extends VehiculeTerrestre
{

    @XmlElement(required = true)
    protected String immatriculation;
    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "date")
    protected Date dateCarteGrise;
    @XmlElement(required = true, type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "date")
    protected Date dateProchainControleTechnique;
    @XmlElement(required = true)
    protected String modeAchat;

    /**
     * Obtient la valeur de la propri�t� immatriculation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getImmatriculation() {
        return immatriculation;
    }

    /**
     * D�finit la valeur de la propri�t� immatriculation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setImmatriculation(String value) {
        this.immatriculation = value;
    }

    /**
     * Obtient la valeur de la propri�t� dateCarteGrise.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDateCarteGrise() {
        return dateCarteGrise;
    }

    /**
     * D�finit la valeur de la propri�t� dateCarteGrise.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateCarteGrise(Date value) {
        this.dateCarteGrise = value;
    }

    /**
     * Obtient la valeur de la propri�t� dateProchainControleTechnique.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDateProchainControleTechnique() {
        return dateProchainControleTechnique;
    }

    /**
     * D�finit la valeur de la propri�t� dateProchainControleTechnique.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateProchainControleTechnique(Date value) {
        this.dateProchainControleTechnique = value;
    }

    /**
     * Obtient la valeur de la propri�t� modeAchat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModeAchat() {
        return modeAchat;
    }

    /**
     * D�finit la valeur de la propri�t� modeAchat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModeAchat(String value) {
        this.modeAchat = value;
    }

}
